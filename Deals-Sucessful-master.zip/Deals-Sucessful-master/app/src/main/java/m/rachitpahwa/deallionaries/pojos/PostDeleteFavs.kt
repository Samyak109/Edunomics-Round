package m.rachitpahwa.deallionaries.pojos

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class PostDeleteFavs {
    @SerializedName("merchant_id")
    @Expose
    var merchantID: Int? = null

    @SerializedName("msg")
    @Expose
    var responseMsg: String? = null
}
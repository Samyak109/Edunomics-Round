package m.rachitpahwa.deallionaries.pojos

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class Searchbusiness {

    @SerializedName("merchantid")
    @Expose
    var id: Int? = null
    @SerializedName("isLiked")
    @Expose
    var likeStatus: Boolean? = null
    @SerializedName("slug")
    @Expose
    var slug: String? = null
    @SerializedName("subcategory_name")
    @Expose
    var subcategoryName: String? = null
    @SerializedName("business_name")
    @Expose
    var businessName: String? = null
    @SerializedName("profile_image")
    @Expose
    var profileImage: String? = null
    @SerializedName("business_description")
    @Expose
    var businessDescription: String? = null

}

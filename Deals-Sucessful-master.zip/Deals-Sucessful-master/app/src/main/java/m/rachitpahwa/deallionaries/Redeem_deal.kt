package m.rachitpahwa.deallionaries

import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.navigation.Navigation
import com.bumptech.glide.Glide
import com.google.gson.Gson
import kotlinx.android.synthetic.main.activity_redeem_deal.*
import m.rachitpahwa.deallionaries.API.RetrofitClient
import m.rachitpahwa.deallionaries.utils.SharedPrefManager
import m.rachitpahwa.deallionaries.pojos.DealDetail
import m.rachitpahwa.deallionaries.pojos.RedeemDeal
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

/*
class Redeem_deal : AppCompatActivity() {
    private val r_expire_so: String? = null
    private val r_expire_solution: TextView? = null
    private val r_location_sol: String? = null
    private val r_location_solution: TextView? = null
    private var r_product_image: ImageView? = null
    private val r_type_sol: String? = null
    private val r_type_solution: TextView? = null
    private val redeem_category_sol: String? = null
    private val redeem_category_solution: TextView? = null
    private val redeem_expire: TextView? = null
    private val redeem_location: TextView? = null
    private val redeem_offer_category: TextView? = null
    private val redeem_offer_type: TextView? = null
    private var redeembutton: Button? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        supportActionBar!!.hide()
        setContentView(layout.activity_redeem_deal)
        r_product_image = findViewById<View>(id.redeem_title_image) as ImageView
        redeembutton = findViewById<View>(id.reedem_button) as Button
        r_product_image = findViewById<View>(id.redeem_product_image) as ImageView
        r_product_image!!.setImageResource(drawable.product1)
        r_product_image!!.visibility = View.INVISIBLE
        redeembutton!!.setOnClickListener { this@Redeem_deal.startActivity(Intent(this@Redeem_deal, Single_product::class.java)) }
    }
}*/

class Redeem_deal : AppCompatActivity() {

    private lateinit var dealData: RedeemDeal
    internal var token: String? = null
    internal lateinit var sharedPrefManager: SharedPrefManager
    internal var id: Int = 0

    internal var dealDetail: DealDetail? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        supportActionBar!!.hide()
        setContentView(R.layout.activity_redeem_deal)
        sharedPrefManager = SharedPrefManager(this@Redeem_deal)
        token = sharedPrefManager.userDetails
        Log.e("Redeem Deal","$token")
        dealData = RedeemDeal()
        val intent = intent
        id = intent.getIntExtra("dealid", 0)
        Log.e("Redeem Deal", "Id recieved is $id")
        redeem_title_image.visibility = View.VISIBLE
        reedem_button.setOnClickListener {
            Log.e("Redeem Deal", "${dealData.dealid}, " +
                    "${dealData.merchantid}, ${dealData.offerTypeId}, ${dealData.customerBaseOfferTypeId}, " +
                    "${dealData.regularPrice}, ${dealData.offerPrice}, ${dealData.discount}, ${dealData.loyaltyPoints}, ${dealData.offerCategoryId}")
            //Call API
            val apiService = RetrofitClient.apiService
            apiService.redeemDeal(token, dealData)?.enqueue(object : Callback<RedeemDeal> {
                override fun onResponse(call: Call<RedeemDeal>, response: Response<RedeemDeal>) {
                    Log.e("Reedem_deal", "onResponse: " + Gson().toJson(response.body()))
                    if (response.isSuccessful) {
                        when(dealData.dealMsg){
                            "Reedem deal has been done" -> {
                                Toast.makeText(applicationContext, "Deal Reedemed", Toast.LENGTH_LONG).show()
                                Navigation.createNavigateOnClickListener(R.id.redeemedDeals)
                            }
                            "All fields are required" -> Toast.makeText(applicationContext, "Some field missing", Toast.LENGTH_LONG).show()
                            else -> Log.e("Redeem_deal", "$response.body().getMessage()")
                        }
                    }
                }
                override fun onFailure(call: Call<RedeemDeal>, t: Throwable) {

                }
            })
        }
        if (id != -1) {
            getDealInfo()
        }
    }

    private fun getDealInfo() {
        //Call API
        val apiService = RetrofitClient.apiService
        apiService.dealDetail(id)?.enqueue(object : Callback<DealDetail> {
            override fun onResponse(call: Call<DealDetail>, response: Response<DealDetail>) {
                Log.e("Redeem_deal", "onResponse: " + Gson().toJson(response.body()))
                //Get Data
                dealDetail = response.body()
                //Update Data
                dealDetail?.dealsdetail?.forEach {
                    dealData.merchantid = it.merchantid.toString()
                    dealData.dealid = id.toString()
                    dealData.offerTypeId = it.offerTypeId.toString()
                    dealData.offerCategoryId = it.offerCategoryId.toString()
                    dealData.loyaltyPoints = it.loyaltyPoints.toString()
                    dealData.regularPrice = it.regularPrice.toString()
                    dealData.offerPrice = it.offerPrice.toString()
                    dealData.discount = it.discount.toString()
                    if (it.customerBaseOfferTypeId != null)
                        dealData.customerBaseOfferTypeId = it.customerBaseOfferTypeId.toString()
                }
                //Update UI
                dealDetail?.dealsdetail?.forEach {
                    Glide.with(this@Redeem_deal).load("https://deallionaires.com/uploads/merchant/deal_image/thumb_690x345/" + it.dealImage).fitCenter().into(redeem_product_image)
                    dealId.text = it.title
                    dealAddress.text = it.address
                    dealBusinessName.text = it.businessName
                    dealLoyaltyPoints.text = it.loyaltyPoints.toString() + " Reward Points"
                    reedem_realprice.text = it.regularPrice.toString() + "$"
                    reedem_discountprice.text = it.offerPrice.toString() + "$"
                    dealOfferCategory.text = "Offer Category :- " + it.offerCategoryName
                    dealOfferType.text = "Offer Type :- " + it.offerTypeName
                }
            }

            override fun onFailure(call: Call<DealDetail>, t: Throwable) {
                Log.e("Redeem_deal", "onFailure: " + t.localizedMessage)
            }
        })
    }
}

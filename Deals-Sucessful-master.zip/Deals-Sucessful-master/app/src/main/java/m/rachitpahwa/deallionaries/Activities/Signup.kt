package m.rachitpahwa.deallionaries.Activities

import android.annotation.SuppressLint
import android.app.DatePickerDialog
import android.app.DatePickerDialog.OnDateSetListener
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.util.Patterns
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.ItemTouchHelper
import com.google.gson.Gson
import kotlinx.android.synthetic.main.activity_signup.*
import m.rachitpahwa.deallionaries.API.Api
import m.rachitpahwa.deallionaries.API.RetrofitClient
import m.rachitpahwa.deallionaries.Model.DefaultResponse
import m.rachitpahwa.deallionaries.R.id
import m.rachitpahwa.deallionaries.R.layout
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.util.*

class Signup : AppCompatActivity() {
    private var address: EditText? = null
    private var co_password: EditText? = null
    private var datedisplay: TextView? = null
    private var datepicker: Button? = null
    private var email: EditText? = null
    private var fname: EditText? = null
    private var lname: EditText? = null
    private val mDatesetListner: OnDateSetListener? = null
    private var mob_no: EditText? = null
    private var password: EditText? = null
    private var sigbutton: Button? = null
    private var gender: String? = null
    //private var group: RadioGroup? = null
    //private var radioButton: RadioButton? = null
    //private var radioId = 0
    private var mYear = 0
    private var mMonth = 0
    private var mDay = 0
    private val mHour = 0
    private val mMinute = 0
    @SuppressLint("SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        supportActionBar!!.hide()
        setContentView(layout.activity_signup)
        window.setFlags(1024, 1024)
        datepicker = findViewById<View>(id.datepicker) as Button
        datedisplay = findViewById<View>(id.date) as TextView
        fname = findViewById<View>(id.Signup_fname) as EditText
        lname = findViewById<View>(id.Signup_lname) as EditText
        email = findViewById<View>(id.signup_emailid) as EditText
        mob_no = findViewById<View>(id.signup_mobile) as EditText
        password = findViewById<View>(id.signup_password) as EditText
        co_password = findViewById<View>(id.signup_co_password) as EditText
        address = findViewById<View>(id.Address) as EditText
        sigbutton = findViewById<View>(id.signupBtn1) as Button
        //group = findViewById<View>(id.gender_radio) as RadioGroup
        /*radioId = group?.checkedRadioButtonId ?: return
        radioButton = findViewById<View>(radioId) as RadioButton*/
        gender_radio.setOnCheckedChangeListener { group, checkedId ->
            val radioButton = findViewById<RadioButton>(checkedId)
            Toast.makeText(baseContext, "${radioButton.text} Selected", Toast.LENGTH_SHORT).show()
            when(radioButton.text){
                "Male" -> gender = "male"
                "Female" -> gender = "female"
            }
        }
        datepicker!!.setOnClickListener {
            val context: Context = this@Signup
            val c: Calendar = Calendar.getInstance()
            mYear = c.get(Calendar.YEAR)
            mMonth = c.get(Calendar.MONTH)
            mDay = c.get(Calendar.DAY_OF_MONTH)
            val datePickerDialog = DatePickerDialog(this@Signup,
                    OnDateSetListener { _, year, monthOfYear, dayOfMonth -> datedisplay!!.text = "DOB:" + year.toString() + "/" + (monthOfYear + 1).toString() + "/" + dayOfMonth.toString() }, mYear, mMonth, mDay)
            datePickerDialog.show()
        }
        sigbutton!!.setOnClickListener { usersignup(gender) }
    }

    private fun usersignup(gender: String?) {

        Log.d("Signup", "Value of gender is $gender")
        Log.d("Signup","Date entered is ${datedisplay?.text.toString()}")

        /*if(radioButton != null) {
            radioId = group?.checkedRadioButtonId ?: return
            radioButton = findViewById<View>(radioId) as RadioButton
        } else {
            radioButton?.error = "Please Select your Gender"
            radioButton?.requestFocus()
        }*/
        val first_name = fname?.text.toString().trim { it <= ' ' }
        val last_name = lname?.text.toString().trim { it <= ' ' }
        val Address = address?.text.toString().trim { it <= ' ' }
        val semail = email?.text.toString().trim { it <= ' ' }
        val mobile = mob_no?.text.toString().trim { it <= ' ' }
        val pass = password?.text.toString().trim { it <= ' ' }
        val co_pass = co_password?.text.toString().trim { it <= ' ' }
        when {
            first_name.isEmpty() -> {
                fname!!.error = "First name required"
                fname!!.requestFocus()
            }
            semail.isEmpty() -> {
                email!!.error = "Email required"
                email!!.requestFocus()
            }
            mobile.isEmpty() -> {
                mob_no!!.error = "Mobile number is required"
                mob_no!!.requestFocus()
            }
            pass.isEmpty() -> {
                password!!.error = "Password is empty"
                password!!.requestFocus()
            }
            co_pass.isEmpty() -> {
                co_password!!.error = "Confirm your password"
                co_password!!.requestFocus()
            }
            gender.isNullOrEmpty() -> {
                Toast.makeText(baseContext, "Please Select your Gender.", Toast.LENGTH_SHORT).show()
            }
            Patterns.EMAIL_ADDRESS.matcher(semail).matches() -> {
                if (pass.length < 6) {
                    password!!.error = "Password Should be more than 6 characters"
                    password!!.requestFocus()
                }
                if(password?.text !== co_password?.text){
                    Log.i("Signup","Both passwords entered are $pass & $co_pass")
                    Toast.makeText(baseContext, "Passwords don't match", Toast.LENGTH_SHORT).show()
                    co_password?.error = "Passwords must be same"
                    co_password?.requestFocus()
                } else {
                    //Call API
                    val apiService = RetrofitClient.apiService
                    apiService.adduser(first_name, last_name, Address, semail, mobile, pass, gender, datedisplay?.text.toString())?.enqueue(object : Callback<DefaultResponse?> {
                        override fun onResponse(call: Call<DefaultResponse?>?, response: Response<DefaultResponse?>) {
                            Log.e("Signup", "onResponse: " + Gson().toJson(response.body()))
                            if (response.code() == ItemTouchHelper.Callback.DEFAULT_DRAG_ANIMATION_DURATION) {
                                Toast.makeText(this@Signup, response.body()!!.message, Toast.LENGTH_LONG).show()
                                Log.i("response", response.toString())

                                val redirectIntent = Intent(applicationContext, Login::class.java)
                                Toast.makeText(this@Signup, "Registration Successful. Please Login.", Toast.LENGTH_LONG).show()
                                startActivity(redirectIntent)
                                return
                            }
                            Toast.makeText(this@Signup, "Something went Wrong", Toast.LENGTH_LONG).show()
                        }

                        override fun onFailure(call: Call<DefaultResponse?>?, t: Throwable) {
                            Log.e("Signup", "onFailure: " + t.localizedMessage)
                        }
                    })
                }
            }
            else -> {
                email!!.error = "Enter valid Email"
                email!!.requestFocus()
            }
        }
    }
}
package m.rachitpahwa.deallionaries.adapter

import android.content.Intent
import com.xwray.groupie.GroupieViewHolder
import com.xwray.groupie.Item
import kotlinx.android.synthetic.main.item_bussiness_branch.view.*
import m.rachitpahwa.deallionaries.Activities.BussinessDetailClass
import m.rachitpahwa.deallionaries.R
import m.rachitpahwa.deallionaries.pojos.Viewbranch

class ItemBussinessBranch(val data: Viewbranch): Item<GroupieViewHolder>(){
    override fun getLayout(): Int {
        return R.layout.item_bussiness_branch
    }

    override fun bind(viewHolder: GroupieViewHolder, position: Int) {
        val view = viewHolder.itemView

        view.branch_title.text = data.businessName
        view.branch_address.text = data.address
        view.branch_contact.text = data.businessContactNo.toString()
        view.setOnClickListener {
            v -> v.context.startActivity(
                Intent(v.context, BussinessDetailClass::class.java)
                        .putExtra("bussId", data.id)
                        .setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP))
        }
    }
}
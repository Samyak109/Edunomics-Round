package m.rachitpahwa.deallionaries.adapter

import android.content.Intent
import com.bumptech.glide.Glide
import com.xwray.groupie.GroupieViewHolder
import com.xwray.groupie.Item
import kotlinx.android.synthetic.main.horizontal_single_row.view.*
import m.rachitpahwa.deallionaries.CategoryListPage
import m.rachitpahwa.deallionaries.R
import m.rachitpahwa.deallionaries.pojos.Category

class ItemCategoriesViewHolder(private val category: Category): Item<GroupieViewHolder>(){
    override fun getLayout(): Int {
        return R.layout.horizontal_single_row
    }

    override fun bind(viewHolder: GroupieViewHolder, position: Int) {
        val view = viewHolder.itemView

        view.category_item_name.text = category.categoryName
        Glide.with(view.context).load(category.bannerImage).into(view.category_icon)
        view.setOnClickListener {
            v -> v.context.startActivity(Intent(v.context, CategoryListPage::class.java).putExtra("category",category.categoryType))
        }
    }
}

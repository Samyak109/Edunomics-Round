package m.rachitpahwa.deallionaries

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.xwray.groupie.GroupAdapter
import com.xwray.groupie.GroupieViewHolder
import kotlinx.android.synthetic.main.applevel_fragment.*
import m.rachitpahwa.deallionaries.API.RetrofitClient
import m.rachitpahwa.deallionaries.R.layout
import m.rachitpahwa.deallionaries.utils.SharedPrefManager
import m.rachitpahwa.deallionaries.adapter.ItemAppLoyaltyPoints
import m.rachitpahwa.deallionaries.pojos.AppLoyaltypoints
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class Fragment_applevel : Fragment() {
    private var appLoyaltypoints: AppLoyaltypoints? = null
    internal var view: View? = null
    internal var token: String? = null
    internal var sharedPrefManager: SharedPrefManager? = null
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater.inflate(layout.applevel_fragment, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val adapter = GroupAdapter<GroupieViewHolder>()
        sharedPrefManager = SharedPrefManager(context!!)
        token = sharedPrefManager?.userDetails
        val mlayoutmanager = LinearLayoutManager(context)
        mlayoutmanager.reverseLayout = true
        mlayoutmanager.stackFromEnd = true
        //Call API
        val apiService = RetrofitClient.apiService
        apiService.getapplayoutpoints(token)?.enqueue(object : Callback<AppLoyaltypoints?> {
            override fun onResponse(call: Call<AppLoyaltypoints?>?, response: Response<AppLoyaltypoints?>) {
                appLoyaltypoints = response.body()
                appLoyaltypoints?.app?.forEach {
                    adapter.add(ItemAppLoyaltyPoints(it))
                }
                app_recyclerview.layoutManager = mlayoutmanager
                app_recyclerview.adapter = adapter
            }
            override fun onFailure(call: Call<AppLoyaltypoints?>?, t: Throwable?) {}
        })
    }
}
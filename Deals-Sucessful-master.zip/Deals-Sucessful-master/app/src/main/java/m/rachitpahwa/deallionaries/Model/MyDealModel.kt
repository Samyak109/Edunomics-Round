package m.rachitpahwa.deallionaries.Model

class MyDealModel(var mydealimage: Int, var mydeal_shopname: String, var mydeal_description: String, var mydeal_price: String, var expireon: String, var reference: String, var transaction: String)
package m.rachitpahwa.deallionaries.fragments

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.ViewModelProviders
import androidx.recyclerview.widget.LinearLayoutManager
import com.xwray.groupie.GroupAdapter
import com.xwray.groupie.GroupieViewHolder
import kotlinx.android.synthetic.main.fragment_business_review.*

import m.rachitpahwa.deallionaries.R
import m.rachitpahwa.deallionaries.adapter.ItemReviewRating
import m.rachitpahwa.deallionaries.pojos.Viewdeal
import m.rachitpahwa.deallionaries.pojos.Viewreviewrating
import m.rachitpahwa.deallionaries.viewModels.BussinessViewModel

class BusinessReview : Fragment() {

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_business_review, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        //View Model
        val reviewsList: List<Viewreviewrating>?
        val bussVM = ViewModelProviders.of(activity!!)[BussinessViewModel::class.java]
        val adapter = GroupAdapter<GroupieViewHolder>()
        reviewsList = bussVM.getReviews()
        reviewsList?.forEach {
            adapter.add(ItemReviewRating(it))
        }
        buss_review_recyclerview.layoutManager = LinearLayoutManager(context, LinearLayoutManager.VERTICAL, false)
        buss_review_recyclerview.adapter = adapter
    }
}

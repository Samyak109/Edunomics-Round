package m.rachitpahwa.deallionaries.Model

class Test(var image1: Int, var image2: Int, var name: String, var price: String)
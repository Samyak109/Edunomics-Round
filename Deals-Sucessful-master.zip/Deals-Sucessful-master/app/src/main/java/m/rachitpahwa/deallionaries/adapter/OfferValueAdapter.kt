package m.rachitpahwa.deallionaries.adapter

import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView.Adapter
import androidx.recyclerview.widget.RecyclerView.ViewHolder
import m.rachitpahwa.deallionaries.R.id
import m.rachitpahwa.deallionaries.R.layout
import m.rachitpahwa.deallionaries.Redeem_deal
import m.rachitpahwa.deallionaries.pojos.OfferValue

class OfferValueAdapter(private val offervaluepoint: OfferValue) : Adapter<OfferValueAdapter.MyViewHolder>() {
    private val offerValues: List<OfferValue?>? = null

    inner class MyViewHolder(view: View) : ViewHolder(view) {
        //var Image: ImageView = view.findViewById<View>(id.usershop_image) as ImageView
        var location: TextView = view.findViewById<View>(id.usercategory_location) as TextView
        var point: TextView = view.findViewById<View>(id.user_points) as TextView
        var shopnme: TextView = view.findViewById<View>(id.usershop1_name) as TextView

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        return MyViewHolder(LayoutInflater.from(parent.context).inflate(layout.item_business, parent, false))
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        val offervaluepoints = offervaluepoint.offervaluepoints
        holder.shopnme.text = offervaluepoints!![position].businessName
        holder.location.text = offervaluepoints[position].address
        holder.point.setText(offervaluepoints[position].loyaltyPoints!!)
        holder.itemView.setOnClickListener { v -> v.context.startActivity(Intent(v.context, Redeem_deal::class.java)) }
    }

    override fun getItemCount(): Int {
        /*Log.d("error", String.valueOf(this.offerValues.getBussinesscategory().size()));
        return this.bussinesscategory.getBussinesscategory().size();*/
        return 0
    }

}
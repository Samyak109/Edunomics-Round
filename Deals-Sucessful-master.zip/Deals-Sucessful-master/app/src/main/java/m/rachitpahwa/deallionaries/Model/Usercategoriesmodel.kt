package m.rachitpahwa.deallionaries.Model

class Usercategoriesmodel(var shopname: String, var location: String, var points: String, var usercategory_image: Int)
package m.rachitpahwa.deallionaries.fragments

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import androidx.lifecycle.ViewModelProviders
import com.xwray.groupie.GroupAdapter
import com.xwray.groupie.GroupieViewHolder
import kotlinx.android.synthetic.main.activity_bussiness_detail.*
import kotlinx.android.synthetic.main.fragment_business_deals.*
import m.rachitpahwa.deallionaries.Activities.BussinessDetailClass

import m.rachitpahwa.deallionaries.R
import m.rachitpahwa.deallionaries.adapter.ItemBussDealSort
import m.rachitpahwa.deallionaries.adapter.ItemDealsList
import m.rachitpahwa.deallionaries.pojos.Viewdeal
import m.rachitpahwa.deallionaries.viewModels.BussinessViewModel
import java.util.*
import kotlin.Comparator

class BusinessDeals : Fragment() {

    //private var dealsList: List<Viewdeal>? = null
    //private var adapter: GroupAdapter<GroupieViewHolder>? = null

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_business_deals, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        //View Model
        val dealsList: List<Viewdeal>?
        val bussVM = ViewModelProviders.of(activity!!)[BussinessViewModel::class.java]
        val adapter = GroupAdapter<GroupieViewHolder>()
        dealsList = bussVM.getDeals() //Fetch Data from View Model

        //Setup Spinner
        val strings = arrayOf("No Filters", "Category Based Deals", "Exclusive Deals", "Inhouse Deals")
        buss_deal_spinner.adapter = ArrayAdapter(context, R.layout.support_simple_spinner_dropdown_item, strings)
        buss_deal_spinner.onItemSelectedListener = object: AdapterView.OnItemSelectedListener{
            override fun onNothingSelected(parent: AdapterView<*>?) {

            }
            //Sort Data
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                when(position){
                    0 -> {
                        adapter.clear() //Clear previous items in recyclerview
                        buss_deals_recyclerview.adapter?.notifyDataSetChanged()
                        dealsList?.forEach { adapter.add(ItemBussDealSort(it)) }
                        //buss_deals_recyclerview.adapter = adapter
                    }
                    1 -> {
                        adapter.clear() //Clear previous items in recyclerview
                        buss_deals_recyclerview.adapter?.notifyDataSetChanged()
                        val catBasedList = dealsList?.filter { it.slug == "customer-category-based-offers" }
                        catBasedList?.forEach { adapter.add(ItemBussDealSort(it)) }
                        //buss_deals_recyclerview.adapter = adapter
                    }
                    2 -> {
                        adapter.clear() //Clear previous items in recyclerview
                        buss_deals_recyclerview.adapter?.notifyDataSetChanged()
                        val exclusiveList = dealsList?.filter { it.slug == "exclusive-offers" }
                        exclusiveList?.forEach { adapter.add(ItemBussDealSort(it)) }
                        //buss_deals_recyclerview.adapter = adapter
                    }
                    3 -> {
                        adapter.clear() //Clear previous items in recyclerview
                        buss_deals_recyclerview.adapter?.notifyDataSetChanged()
                        val inHouseList = dealsList?.filter { it.slug == "in-house-offers" }
                        inHouseList?.forEach { adapter.add(ItemBussDealSort(it)) }
                        //buss_deals_recyclerview.adapter = adapter
                    }
                }
                buss_deals_recyclerview.adapter = adapter
            }
        }
    }

}

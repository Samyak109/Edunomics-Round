package m.rachitpahwa.deallionaries.pojos

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class Dashboard(@field:Expose @field:SerializedName("My_deals") var myDeals: String,
                @field:Expose @field:SerializedName("favourites") var favourites: String,
                @field:Expose @field:SerializedName("Loyalty_points") var loyalty_points: String)
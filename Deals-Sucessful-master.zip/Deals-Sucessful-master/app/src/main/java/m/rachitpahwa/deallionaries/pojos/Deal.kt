package m.rachitpahwa.deallionaries.pojos

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName
import m.rachitpahwa.deallionaries.Model.Horizontalmodel

/*
class Deal(storename: String?,
           price: String?,
           storeimage1: String?,
           storeimage2: Int) : Horizontalmodel(storename, price, storeimage1, storeimage2) {
    @SerializedName("deal_image")
    @Expose
    var dealImage: String? = null
    @SerializedName("description")
    @Expose
    var description: String? = null
    @SerializedName("title")
    @Expose
    var title: String? = null

}
*/

class Deal(storename: String, price: String, storeimage1: String, storeimage2: Int) : Horizontalmodel(storename, price, storeimage1, storeimage2) {

    @SerializedName("merchantsimage")
    @Expose
    var merchantImage: String? = null
    @SerializedName("deal_image")
    @Expose
    var dealImage: String? = null
    @SerializedName("description")
    @Expose
    var description: String? = null
    @SerializedName("title")
    @Expose
    var title: String? = null
    @SerializedName("id")
    @Expose
    var id: Int = 0
}

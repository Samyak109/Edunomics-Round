package m.rachitpahwa.deallionaries

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.xwray.groupie.GroupAdapter
import com.xwray.groupie.GroupieViewHolder
import kotlinx.android.synthetic.main.offerlevel_fragment.*
import m.rachitpahwa.deallionaries.API.RetrofitClient
import m.rachitpahwa.deallionaries.R.layout
import m.rachitpahwa.deallionaries.utils.SharedPrefManager
import m.rachitpahwa.deallionaries.adapter.ItemBussinessCategory
import m.rachitpahwa.deallionaries.pojos.Buscategory
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class Fragment_offerlevel : Fragment() {
    private var buscategory: Buscategory? = null
    internal var view: View? = null
    internal var token: String? = null
    internal var sharedPrefManager: SharedPrefManager? = null
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater.inflate(layout.offerlevel_fragment, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val adapter = GroupAdapter<GroupieViewHolder>()

        sharedPrefManager = SharedPrefManager(context!!)
        token = sharedPrefManager?.userDetails
        val mlayoutmanager = LinearLayoutManager(context)
        mlayoutmanager.reverseLayout = true
        mlayoutmanager.stackFromEnd = true
        //Call API
        val apiService = RetrofitClient.apiService
        apiService.getbuscategory(token)?.enqueue(object : Callback<Buscategory?> {
            override fun onResponse(call: Call<Buscategory?>?, response: Response<Buscategory?>) {
                buscategory = response.body()
                buscategory?.bussinesscategory?.forEach {

                    adapter.add(ItemBussinessCategory(it))
                }
                offer_recyclerview.layoutManager = mlayoutmanager
                offer_recyclerview.adapter = adapter
            }

            override fun onFailure(call: Call<Buscategory?>?, t: Throwable?) {}
        })
    }
}
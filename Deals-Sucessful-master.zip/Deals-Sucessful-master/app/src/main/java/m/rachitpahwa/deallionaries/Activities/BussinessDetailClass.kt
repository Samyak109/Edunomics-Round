package m.rachitpahwa.deallionaries.Activities

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.ImageView
import android.widget.Toast
import androidx.lifecycle.ViewModelProviders
import androidx.viewpager.widget.ViewPager
import com.bumptech.glide.Glide
import com.google.android.material.tabs.TabLayout
import com.like.LikeButton
import com.like.OnLikeListener
import kotlinx.android.synthetic.main.activity_bussiness_detail.*
import m.rachitpahwa.deallionaries.API.RetrofitClient
import m.rachitpahwa.deallionaries.R
import m.rachitpahwa.deallionaries.utils.SharedPrefManager
import m.rachitpahwa.deallionaries.adapter.BussinessPagesAdapter
import m.rachitpahwa.deallionaries.adapter.SliderAdapterExample
import m.rachitpahwa.deallionaries.pojos.BussinessDetail
import m.rachitpahwa.deallionaries.pojos.LoginBusinessData
import m.rachitpahwa.deallionaries.pojos.PostDeleteFavs
import m.rachitpahwa.deallionaries.viewModels.BussinessViewModel
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.text.SimpleDateFormat

class BussinessDetailClass : AppCompatActivity() {

    private lateinit var sharedPrefManager: SharedPrefManager
    private var userData: LoginBusinessData? = null
    private var chunkData: BussinessDetail? = null
    private var token: String? = null
    private var bussId: Int? = null
    private var profileImg: ImageView? = null
    private lateinit var bussinessVM: BussinessViewModel
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_bussiness_detail)

        sharedPrefManager = SharedPrefManager(applicationContext)
        token = sharedPrefManager.userDetails
        val intent = intent
        profileImg = findViewById(R.id.buss_card_profile)
        bussId = intent.getIntExtra("bussId",0)

        //ViewModel
        bussinessVM = ViewModelProviders.of(this@BussinessDetailClass)[BussinessViewModel::class.java]

        buss_detail_like.setOnLikeListener(object: OnLikeListener {

            val postDeleteFavs = PostDeleteFavs()
            override fun liked(likeButton: LikeButton?) {

                if(sharedPrefManager.isLoggedIn){
                    //Call API
                    val apiService = RetrofitClient.apiService
                    apiService.addToFavourites(token, postDeleteFavs)?.enqueue(object: Callback<PostDeleteFavs>{
                        override fun onResponse(call: Call<PostDeleteFavs>, response: Response<PostDeleteFavs>) {
                            if(response.isSuccessful){
                                Toast.makeText(applicationContext, "Added to Favourites", Toast.LENGTH_SHORT).show()
                            }
                        }
                        override fun onFailure(call: Call<PostDeleteFavs>, t: Throwable) {

                        }
                    })
                } else {
                    Toast.makeText(applicationContext, "You need to login first before liking this business.", Toast.LENGTH_LONG).show()
                    buss_detail_like.isLiked = false
                }
            }
            override fun unLiked(likeButton: LikeButton?) {
                //Call API
                val apiService = RetrofitClient.apiService
                apiService.removeFavourite(token, bussId)?.enqueue(object: Callback<PostDeleteFavs>{
                    override fun onResponse(call: Call<PostDeleteFavs>, response: Response<PostDeleteFavs>) {
                        if(response.isSuccessful){
                            Toast.makeText(applicationContext, "Removed from Favourites", Toast.LENGTH_SHORT).show()
                        }
                    }

                    override fun onFailure(call: Call<PostDeleteFavs>, t: Throwable) {

                    }
                })
            }
        })
        validateLogin()
        loadBusinessData()
    }

    private fun validateLogin(){
        if(sharedPrefManager.isLoggedIn){
            buss_club_expiry.visibility = View.VISIBLE
            buss_loyalty_points.visibility = View.VISIBLE
            //Call API
            val apiService = RetrofitClient.apiService
            apiService.getLoginBussinessData(token, bussId)?.enqueue(object: Callback<LoginBusinessData>{
                override fun onResponse(call: Call<LoginBusinessData>, response: Response<LoginBusinessData>) {
                    if(response.isSuccessful){
                        userData = response.body()

                        if(userData?.loginclubexpirydate.isNullOrBlank() || userData?.loginclubexpirydate == "0")
                            buss_club_expiry.text = "Club Expiry Date: N/A"
                        else {
                            val dateFormat = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX")
                            val date = dateFormat.parse(userData?.loginclubexpirydate)
                            val formatter = SimpleDateFormat("yyyy-MM-dd")
                            val dateStr  = formatter.format(date)

                            buss_club_expiry.text = "Club Expiry Date: $dateStr"
                        }
                        buss_loyalty_points.text = "Your Loyalty Points: ${userData?.loginloyaltypoints}"

                        buss_detail_like.isLiked = !(userData?.likeStatus == null || userData?.likeStatus == false)
                    }
                }

                override fun onFailure(call: Call<LoginBusinessData>, t: Throwable) {

                }
            })
        } else {
            buss_club_expiry.visibility = View.GONE
            buss_loyalty_points.visibility = View.GONE
        }
    }

    private fun loadBusinessData(){
        //Call API
        val apiService = RetrofitClient.apiService
        apiService.getBusinessDetail(bussId)?.enqueue(object: Callback<BussinessDetail>{
            override fun onResponse(call: Call<BussinessDetail>, response: Response<BussinessDetail>) {
                if(response.isSuccessful){
                    chunkData = response.body()
                    chunkData?.viewbusinessname?.forEach {
                        Log.e("BussDetail","${it.businessName}, ${it.address}, ${it.profileImage}, ${it.businessDescription}")
                        buss_card_title.text = it.businessName
                        buss_card_address.text = "Address: ${it.address}"
                        buss_card_desc.text = "Description: ${it.businessDescription}"
                        profileImg?.let { it1 -> Glide.with(baseContext).load(it.profileImage).into(it1) }
                    }
                    bussinessVM.sendBranch(chunkData?.viewbranch)
                    chunkData?.viewbusinessrating?.forEach {
                        Log.e("BussDetail","${it.rating}")
                        buss_ratings.text = it.rating.toString()
                    }

                    //Image Slider
                    val count = chunkData?.viewimages?.count()
                    val slider = SliderAdapterExample(count, chunkData?.viewimages)
                    buss_detail_slider.sliderAdapter = slider
                    buss_detail_slider.scrollTimeInSec = 4

                    bussinessVM.sendDeals(chunkData?.viewdeals)
                    chunkData?.viewcategoryname?.forEach {
                        Log.e("BussDetail","${it.categoryName}")
                        if(it.categoryName.isNullOrBlank())
                            buss_card_category.text = "N/A"
                        else
                            buss_card_category.text = it.categoryName
                    }
                    chunkData?.viewsubcategoryname?.forEach {
                        Log.e("BussDetail","${it.subcategoryName}")
                        if(it.subcategoryName.isNullOrBlank())
                            buss_card_subcat.text = "N/A"
                        else
                            buss_card_subcat.text = it.subcategoryName
                    }
                    bussinessVM.sendReviews(chunkData?.viewreviewrating)
                }

                setupViewPager() //Attmpt at when Viewpager is initiated after the data is fetched and loaded
            }

            override fun onFailure(call: Call<BussinessDetail>, t: Throwable) {

            }
        })
    }

    private fun setupViewPager(){
        buss_detail_options_tabs.addTab(buss_detail_options_tabs.newTab().setText("Deals"))
        buss_detail_options_tabs.addTab(buss_detail_options_tabs.newTab().setText("Branches"))
        buss_detail_options_tabs.addTab(buss_detail_options_tabs.newTab().setText("Contact"))
        buss_detail_options_tabs.addTab(buss_detail_options_tabs.newTab().setText("Reviews"))
        buss_detail_options_tabs.tabGravity = TabLayout.GRAVITY_FILL

        val viewPagerAdapter = BussinessPagesAdapter(supportFragmentManager, buss_detail_options_tabs.tabCount)
        viewPagerAdapter.notifyDataSetChanged()
        buss_viewpager.adapter = viewPagerAdapter
        buss_viewpager.offscreenPageLimit = 1
        buss_detail_options_tabs.setupWithViewPager(buss_viewpager)
        buss_viewpager.addOnPageChangeListener(object: ViewPager.OnPageChangeListener{
            override fun onPageSelected(position: Int) {
                buss_viewpager.adapter?.notifyDataSetChanged()
                buss_viewpager.currentItem = position
                TabLayout.TabLayoutOnPageChangeListener(buss_detail_options_tabs)
            }

            override fun onPageScrolled(position: Int, positionOffset: Float, positionOffsetPixels: Int) {

            }

            override fun onPageScrollStateChanged(state: Int) {

            }
        })
    }
}

package m.rachitpahwa.deallionaries.pojos

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class Offervaluepoint {
    @SerializedName("id")
    @Expose
    var id: Int? = null
    @SerializedName("business_name")
    @Expose
    var businessName: String? = null
    @SerializedName("loyalty_points")
    @Expose
    var loyaltyPoints: Int? = null
    @SerializedName("profile_image")
    @Expose
    var profileImage: String? = null
    @SerializedName("address")
    @Expose
    var address: String? = null

}
package m.rachitpahwa.deallionaries.adapter

import com.xwray.groupie.GroupieViewHolder
import com.xwray.groupie.Item
import kotlinx.android.synthetic.main.item_notifications.view.*
import m.rachitpahwa.deallionaries.R
import m.rachitpahwa.deallionaries.pojos.Notiadmin
import m.rachitpahwa.deallionaries.pojos.Notimerchant
import java.text.SimpleDateFormat

class ItemAdminNotifications(private val notifs: Notiadmin): Item<GroupieViewHolder>(){
    override fun getLayout(): Int {
        return R.layout.item_notifications
    }
    override fun bind(viewHolder: GroupieViewHolder, position: Int) {
        val view = viewHolder.itemView

        val dateFormat = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX")
        val date = dateFormat.parse(notifs.createdAt)
        val formatter = SimpleDateFormat("yyyy-MM-dd")
        val dateStr  = formatter.format(date)

        view.notiBussiness.text = notifs.description
        view.notiDesc.text = dateStr
        view.setOnClickListener {

        }
    }
}

class ItemMerchantNotifications(private val notifs: Notimerchant): Item<GroupieViewHolder>(){
    override fun getLayout(): Int {
        return R.layout.item_notifications
    }
    override fun bind(viewHolder: GroupieViewHolder, position: Int) {
        val view = viewHolder.itemView

        view.notiTitle.text = notifs.title
        view.notiBussiness.text = notifs.businessName
        view.notiDesc.text = notifs.description
        view.setOnClickListener {

        }
    }
}
package m.rachitpahwa.deallionaries.Activities

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Bitmap.CompressFormat
import android.graphics.BitmapFactory
import android.os.Bundle
import android.provider.MediaStore.Images.Media
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AlertDialog.Builder
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import de.hdodenhof.circleimageview.CircleImageView
import kotlinx.android.synthetic.main.activity_profile.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import m.rachitpahwa.deallionaries.API.RetrofitClient
import m.rachitpahwa.deallionaries.R
import m.rachitpahwa.deallionaries.R.id
import m.rachitpahwa.deallionaries.R.layout
import m.rachitpahwa.deallionaries.utils.SharedPrefManager
import m.rachitpahwa.deallionaries.pojos.EditProfile
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.io.ByteArrayOutputStream
import java.io.IOException

class ProfileActivity : AppCompatActivity() {

    private var editProfile: EditProfile? = null
    private lateinit var photo: ByteArray
    private var takepicture: CircleImageView? = null
    internal var sharedPrefManager: SharedPrefManager? = null
    private var postData: EditProfile? = null

    private var job: Job = Job()
    private val uiScope = CoroutineScope(Dispatchers.Main)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        supportActionBar?.hide()
        setContentView(layout.activity_profile)
        sharedPrefManager = SharedPrefManager(this@ProfileActivity)
        tog_profile_img.setOnClickListener {
            val builder = Builder(this@ProfileActivity)
            val dialogLayout: View = this@ProfileActivity.layoutInflater.inflate(layout.bottom_layout_profilepic, null)
            val dialog: AlertDialog = builder.create()
            dialog.window.setSoftInputMode(3)
            dialog.setView(dialogLayout, 0, 0, 0, 0)
            dialog.setCanceledOnTouchOutside(true)
            dialog.setCancelable(true)
            dialog.window.attributes.gravity = 80
            val btnCamera = dialogLayout.findViewById<View>(id.camera) as CircleImageView
            val btnGallery = dialogLayout.findViewById<View>(id.gallery) as CircleImageView
            val btnDismiss = dialogLayout.findViewById<View>(id.btnCancelCamera) as Button
            builder.setView(dialogLayout)
            dialog.show()
            btnCamera.setOnClickListener {
                this@ProfileActivity.startActivityForResult(Intent("android.media.action.IMAGE_CAPTURE"), CAMERA_REQUEST)
                dialog.dismiss()
            }
            btnGallery.setOnClickListener {
                Toast.makeText(this@ProfileActivity, "Gallery Opening", Toast.LENGTH_LONG).show()
                openGallery()
                dialog.dismiss()
            }
            btnDismiss.setOnClickListener { dialog.dismiss() }
        }
        //Call API
        val apiService = RetrofitClient.apiService
        uiScope.launch {
            val data = apiService.getUserInfo(sharedPrefManager?.userDetails)
            getdata(data)
        }

        profile_edit.setOnClickListener {
            profile_save.visibility = View.VISIBLE
            profile_edit.visibility = View.GONE
            tog_enabler.performClick()
        }

        profile_save.setOnClickListener {
            profile_edit.visibility = View.VISIBLE
            profile_edit.visibility = View.GONE
            tog_enabler.performClick()
        }

        tog_enabler.bind(tog_name, tog_last_name, tog_email, tog_country, tog_state, tog_apt_building, tog_street_addr, tog_gender, tog_dob)
        tog_enabler.setOnClickListener {
            postData = EditProfile()
            postData?.result?.forEach {
                it.firstName = tog_name.editText.text.toString()
                it.lastName = tog_last_name.editText.text.toString()
                it.email = tog_email.editText.toString()
                it.country = tog_state.editText.toString()
                it.address = tog_apt_building.editText.text.toString()
                it.mobileNumber = tog_street_addr.editText.text.toString()
                it.gender = tog_gender.editText.text.toString()
                it.dateOfBirth = tog_gender.editText.text.toString()
            }
            if(!postData?.result.isNullOrEmpty()){
                setdata()
            } else {
                return@setOnClickListener
            }
        }
    }

    private fun getdata(data: EditProfile?) {

        editProfile = data
        editProfile?.result?.forEach {
            Glide.with(applicationContext).load(it.profileImage).placeholder(R.drawable.slide7).into(tog_profile_img)
            tog_name.textView.text = it.firstName
            tog_last_name.textView.text = it.lastName
            tog_email.textView.text = it.email
            tog_country.textView.text = it.country
            tog_state.textView.text = it.state
            tog_apt_building.textView.text = it.address
            tog_street_addr.textView.text = it.mobileNumber
            tog_gender.textView.text = it.gender
            tog_dob.textView.text = it.dateOfBirth
        }
    }

    private fun setdata(){

        //Call API
        val apiService = RetrofitClient.apiService
        apiService.edited(postData)?.enqueue(object: Callback<EditProfile?>{
            override fun onResponse(call: Call<EditProfile?>, response: Response<EditProfile?>) {

            }
            override fun onFailure(call: Call<EditProfile?>, t: Throwable) {
                Toast.makeText(applicationContext, "Oops, No data was passed.", Toast.LENGTH_SHORT).show()
                Log.e("Profile","$t")
            }
        })

    }

    private fun openGallery() {
        val intent = Intent()
        intent.type = "image/*"
        intent.action = "android.intent.action.GET_CONTENT"
        startActivityForResult(intent, GALLERY_REQUEST)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == -1) {
            val stringBuilder = StringBuilder()
            stringBuilder.append("RequestCode is ")
            stringBuilder.append(requestCode)
            Toast.makeText(this, stringBuilder.toString(), Toast.LENGTH_LONG).show()
            val str = "coming "
            val pic: Bitmap?
            val stringBuilder2: StringBuilder
            if (requestCode == CAMERA_REQUEST) {
                pic = data?.extras?.get("data") as Bitmap
                if (pic != null) {
                    photo = profileImage(pic)
                    takepicture?.setImageBitmap(pic)
                    stringBuilder2 = StringBuilder()
                    stringBuilder2.append(str)
                    stringBuilder2.append(photo)
                    Toast.makeText(this, stringBuilder2.toString(), Toast.LENGTH_LONG).show()
                }
            } else if (requestCode == GALLERY_REQUEST && data != null) {
                try {
                    pic = Media.getBitmap(contentResolver, data.data)
                    photo = profileImage(pic)
                    takepicture?.setImageBitmap(pic)
                    stringBuilder2 = StringBuilder()
                    stringBuilder2.append(str)
                    stringBuilder2.append(photo)
                    Toast.makeText(this, stringBuilder2.toString(), Toast.LENGTH_LONG).show()
                } catch (e: IOException) {
                    e.printStackTrace()
                }
            }
        }
    }

    fun getImageDataInBitmap(imageData: ByteArray?): Bitmap? {
        return if (imageData != null) {
            BitmapFactory.decodeByteArray(imageData, 0, imageData.size)
        } else null
    }

    private fun profileImage(b: Bitmap?): ByteArray {
        val bos = ByteArrayOutputStream()
        b!!.compress(CompressFormat.PNG, 0, bos)
        return bos.toByteArray()
    }

    companion object {
        private const val CAMERA_REQUEST = 5311
        private const val GALLERY_REQUEST = 7777
    }
}
package m.rachitpahwa.deallionaries

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import m.rachitpahwa.deallionaries.R.layout

class Settings : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(layout.activity_settings)
    }
}
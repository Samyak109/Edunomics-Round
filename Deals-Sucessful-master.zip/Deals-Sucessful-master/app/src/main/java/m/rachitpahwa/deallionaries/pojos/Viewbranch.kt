package m.rachitpahwa.deallionaries.pojos

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class Viewbranch {

    @SerializedName("id")
    @Expose
    var id: Int? = null
    @SerializedName("business_name")
    @Expose
    var businessName: String? = null
    @SerializedName("address")
    @Expose
    var address: String? = null
    @SerializedName("business_contact_no")
    @Expose
    var businessContactNo: Any? = null

}
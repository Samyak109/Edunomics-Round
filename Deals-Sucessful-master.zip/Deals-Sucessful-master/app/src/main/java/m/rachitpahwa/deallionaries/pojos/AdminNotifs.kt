package m.rachitpahwa.deallionaries.pojos

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName


class AdminNotifs {

    @SerializedName("notiadmin")
    @Expose
    var notiadmin: List<Notiadmin>? = null

}
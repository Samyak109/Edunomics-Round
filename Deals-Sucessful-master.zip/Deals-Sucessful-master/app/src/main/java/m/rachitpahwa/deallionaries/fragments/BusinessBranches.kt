package m.rachitpahwa.deallionaries.fragments

import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.ViewModelProviders
import com.xwray.groupie.GroupAdapter
import com.xwray.groupie.GroupieViewHolder
import kotlinx.android.synthetic.main.fragment_business_branches.*
import m.rachitpahwa.deallionaries.R
import m.rachitpahwa.deallionaries.adapter.ItemBussinessBranch
import m.rachitpahwa.deallionaries.pojos.Viewbranch
import m.rachitpahwa.deallionaries.viewModels.BussinessViewModel

class BusinessBranches : Fragment() {

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_business_branches, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        //ViewModel
        val branchList: List<Viewbranch>?
        val bussVM = ViewModelProviders.of(activity!!)[BussinessViewModel::class.java]
        val adapter = GroupAdapter<GroupieViewHolder>()
        branchList = bussVM.getBranch()
        branchList?.forEach {
            Log.e("branchFragment","${it.id},${it.businessName},${it.address},${it.businessContactNo}")
            adapter.add(ItemBussinessBranch(it))
        }
        buss_branch_recyclerview.adapter = adapter
    }
}

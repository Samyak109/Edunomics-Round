package m.rachitpahwa.deallionaries.Model

class Myfavouritesmodel(var image: Int, var storenme: String, var location: String)
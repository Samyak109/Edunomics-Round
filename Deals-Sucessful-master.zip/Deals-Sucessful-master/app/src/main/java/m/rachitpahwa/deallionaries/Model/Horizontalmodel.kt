package m.rachitpahwa.deallionaries.Model

open class Horizontalmodel {
    var price: String? = null
    var storeimage1: String? = null
    var storeimage2 = 0
    var storename: String? = null

    constructor()
    constructor(storename: String?, price: String?, storeimage1: String?, storeimage2: Int) {
        this.storename = storename
        this.price = price
        this.storeimage1 = storeimage1
        this.storeimage2 = storeimage2
    }
}

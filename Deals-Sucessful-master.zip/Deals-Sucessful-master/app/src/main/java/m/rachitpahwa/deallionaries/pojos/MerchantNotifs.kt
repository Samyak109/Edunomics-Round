package m.rachitpahwa.deallionaries.pojos

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName


class MerchantNotifs {

    @SerializedName("notimerchant")
    @Expose
    var notimerchant: List<Notimerchant>? = null

}
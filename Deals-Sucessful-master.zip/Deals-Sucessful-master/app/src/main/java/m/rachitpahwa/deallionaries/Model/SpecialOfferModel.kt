package m.rachitpahwa.deallionaries.Model

class SpecialOfferModel(var dealimage: Int,
                        var spoffer_name: String,
                        var apofer_desc: String,
                        var spoffer_fp: String,
                        var spoffer_dp: String)

package m.rachitpahwa.deallionaries.pojos

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class OfferValue {
    @SerializedName("offervaluepoints")
    @Expose
    var offervaluepoints: List<Offervaluepoint>? = null

}
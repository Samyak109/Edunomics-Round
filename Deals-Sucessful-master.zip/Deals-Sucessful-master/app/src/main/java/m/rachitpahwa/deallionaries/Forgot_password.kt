package m.rachitpahwa.deallionaries

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.view.View.OnClickListener
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_forgot_password.*
import m.rachitpahwa.deallionaries.API.Api
import m.rachitpahwa.deallionaries.API.RetrofitClient
import m.rachitpahwa.deallionaries.Activities.Login
import m.rachitpahwa.deallionaries.R.id
import m.rachitpahwa.deallionaries.R.layout
import m.rachitpahwa.deallionaries.pojos.ForgotPassword
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class Forgot_password : AppCompatActivity() {
    private var back: TextView? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        supportActionBar?.hide()
        setContentView(layout.activity_forgot_password)
        back = findViewById<View>(id.back) as TextView
        var email: String?
        var forgotPassword: ForgotPassword? = ForgotPassword()
        btn_reset.setOnClickListener(OnClickListener {
            if (reset_email.text.toString().isEmpty()) {
                reset_email.error = "Please Provide a registered email"
                reset_email.requestFocus()
                return@OnClickListener
            } else {
                email = reset_email.text.toString()
                forgotPassword?.email = email
            }
            //Call API
            val apiService = RetrofitClient.apiService
            apiService.sendForgotEmmail()?.enqueue(object: Callback<ForgotPassword>{
                override fun onResponse(call: Call<ForgotPassword>, response: Response<ForgotPassword>) {
                    if(response.isSuccessful){
                        forgotPassword = response.body()
                        Toast.makeText(applicationContext, "${forgotPassword?.forgotResponse}", Toast.LENGTH_SHORT).show()
                        this@Forgot_password.startActivity(Intent(this@Forgot_password, Forgotpassword2::class.java))
                    }
                }

                override fun onFailure(call: Call<ForgotPassword>, t: Throwable) {

                }
            })
            this@Forgot_password.startActivity(Intent(this@Forgot_password, Forgotpassword2::class.java))
        })
        back?.setOnClickListener { this@Forgot_password.startActivity(Intent(this@Forgot_password, Login::class.java)) }
    }
}
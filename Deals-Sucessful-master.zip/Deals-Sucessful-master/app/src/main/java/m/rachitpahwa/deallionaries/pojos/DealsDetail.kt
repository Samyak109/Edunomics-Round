package m.rachitpahwa.deallionaries.pojos

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class Dealsdetail {

    @SerializedName("merchantid")
    @Expose
    var merchantid: Int? = null
    @SerializedName("category_name")
    @Expose
    var categoryName: String? = null
    @SerializedName("business_name")
    @Expose
    var businessName: String? = null
    @SerializedName("title")
    @Expose
    var title: String? = null
    @SerializedName("address")
    @Expose
    var address: String? = null
    @SerializedName("offer_category_name")
    @Expose
    var offerCategoryName: String? = null
    @SerializedName("offer_type_name")
    @Expose
    var offerTypeName: String? = null
    @SerializedName("regular_price")
    @Expose
    var regularPrice: Int? = null
    @SerializedName("offer_price")
    @Expose
    var offerPrice: Int? = null
    @SerializedName("discount")
    @Expose
    var discount: Int? = null
    @SerializedName("saving_amount")
    @Expose
    var savingAmount: Int? = null
    @SerializedName("deal_image")
    @Expose
    var dealImage: String? = null
    @SerializedName("offer_type_id")
    @Expose
    var offerTypeId: Int? = null
    @SerializedName("offer_category_id")
    @Expose
    var offerCategoryId: Int? = null
    @SerializedName("loyalty_points")
    @Expose
    var loyaltyPoints: Int? = null
    @SerializedName("customer_base_offer_type_id")
    @Expose
    var customerBaseOfferTypeId: Any? = null

}

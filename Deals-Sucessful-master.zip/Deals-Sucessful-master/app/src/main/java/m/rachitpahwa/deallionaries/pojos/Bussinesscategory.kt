package m.rachitpahwa.deallionaries.pojos

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class Bussinesscategory {

    @SerializedName("id")
    @Expose
    var bussinessId: Int? = null
    @SerializedName("business_name")
    @Expose
    var businessName: String? = null
    @SerializedName("profile_image")
    @Expose
    var bussProfileImage: String? =  null
    @SerializedName("address")
    @Expose
    var address: String? = null
    @SerializedName("loyalty_points")
    @Expose
    var loyaltyPoints: String? = null
    @SerializedName("category_name")
    @Expose
    var categoryName: String? = null
    @SerializedName("expiry_date")
    @Expose
    var expiryDate: String? = null

}
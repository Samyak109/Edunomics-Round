package m.rachitpahwa.deallionaries.adapter

import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentPagerAdapter
import m.rachitpahwa.deallionaries.fragments.AdminNotifications
import m.rachitpahwa.deallionaries.fragments.MerchantNotifications

class NotificationsAdapter(fm: FragmentManager, private var totalTabs: Int): FragmentPagerAdapter(fm){
    override fun getItem(position: Int): Fragment {
        return when (position) {
            0 -> AdminNotifications()
            else -> return MerchantNotifications()
        }
    }

    override fun getCount(): Int {
        return totalTabs
    }

    override fun getPageTitle(position: Int): CharSequence? {
        return when(position){
            0 -> "Admin Notifications"
            else -> return "Merchant Notifications"
        }
    }
}
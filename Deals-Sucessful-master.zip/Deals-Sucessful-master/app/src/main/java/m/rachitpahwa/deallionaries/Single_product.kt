package m.rachitpahwa.deallionaries

import android.os.Bundle
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import m.rachitpahwa.deallionaries.R.*

class Single_product : AppCompatActivity() {
    private var expire: TextView? = null
    private val expire_sol: String? = null
    private var expire_solution: TextView? = null
    private var location: TextView? = null
    private val location_sol: String? = null
    private var location_solution: TextView? = null
    private var offercategory: TextView? = null
    private val offercategory_sol: String? = null
    private var offercategory_solution: TextView? = null
    private var offertype: TextView? = null
    private val offertype_sol: String? = null
    private var offertype_solution: TextView? = null
    private var product_image: ImageView? = null
    private var title: TextView? = null
    private val title_sol = "StarBucks"
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        supportActionBar!!.hide()
        setContentView(layout.single_product)
        product_image = findViewById<View>(id.product_image) as ImageView
        title = findViewById<View>(id.product_title) as TextView
        offercategory = findViewById<View>(id.product_category) as TextView
        offertype = findViewById<View>(id.offer_type) as TextView
        location = findViewById<View>(id.location) as TextView
        expire = findViewById<View>(id.expire_date) as TextView
        offercategory_solution = findViewById<View>(id.product_category_solution) as TextView
        offertype_solution = findViewById<View>(id.offer_type_solution) as TextView
        location_solution = findViewById<View>(id.location_solution) as TextView
        expire_solution = findViewById<View>(id.expire_date_solution) as TextView
        offercategory_solution!!.text = offercategory_sol
        offertype_solution!!.text = offertype_sol
        location_solution!!.text = location_sol
        expire_solution!!.text = expire_sol
        title!!.text = title_sol
        product_image!!.setImageResource(drawable.product1)
    }
}
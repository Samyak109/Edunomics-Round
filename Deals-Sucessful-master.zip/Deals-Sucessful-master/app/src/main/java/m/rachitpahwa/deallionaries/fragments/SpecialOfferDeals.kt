package m.rachitpahwa.deallionaries.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.GridLayoutManager
import com.xwray.groupie.GroupAdapter
import com.xwray.groupie.GroupieViewHolder
import kotlinx.android.synthetic.main.fragment_special_offer.*
import m.rachitpahwa.deallionaries.API.RetrofitClient
import m.rachitpahwa.deallionaries.R
import m.rachitpahwa.deallionaries.utils.SharedPrefManager
import m.rachitpahwa.deallionaries.adapter.ItemSpecialOffer
import m.rachitpahwa.deallionaries.pojos.SpecialOfferDeals
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class SpecialOfferDeals: Fragment(){

    private var specialOfferDeals: SpecialOfferDeals? = null
    private var imageView: ImageView? = null
    internal var token: String? = null
    internal var sharedPrefManager: SharedPrefManager? = null

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.fragment_special_offer, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        sharedPrefManager = SharedPrefManager(context!!)
        token = sharedPrefManager!!.userDetails
        /*imageView = findViewById<View>(R.id.special_offer_back) as ImageView
        imageView!!.setOnClickListener {
            this@SpecialOfferClass.startActivity(Intent(this@SpecialOfferClass, ContentMainActivity::class.java))
            finish()
        }*/
        val adapter = GroupAdapter<GroupieViewHolder>()

        //Call API
        val apiService = RetrofitClient.apiService
        apiService.getSpecialOffers(token)?.enqueue(object: Callback<SpecialOfferDeals> {
            override fun onResponse(call: Call<SpecialOfferDeals>, response: Response<SpecialOfferDeals>) {
                if(response.isSuccessful){
                    specialOfferDeals = response.body()
                    specialOfferDeals?.specialoffers?.forEach {
                        adapter.add(ItemSpecialOffer(it))
                    }
                }
            }

            override fun onFailure(call: Call<SpecialOfferDeals>, t: Throwable) {

            }
        })
        special_offer.layoutManager = GridLayoutManager(context, 2)
        special_offer.adapter = adapter
    }
}
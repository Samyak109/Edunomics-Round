package m.rachitpahwa.deallionaries.adapter

import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import com.bumptech.glide.Glide
import com.smarteist.autoimageslider.SliderViewAdapter
import m.rachitpahwa.deallionaries.R
import m.rachitpahwa.deallionaries.Redeem_deal

class SliderAdapterExample(private var count: Int?, private val data: List<String>?) : SliderViewAdapter<SliderAdapterExample.SliderAdapterVH>() {

    inner class SliderAdapterVH(var itemView: View) : ViewHolder(itemView) {
        var imageViewBackground: ImageView = itemView.findViewById<View>(R.id.slider_image) as ImageView
        var mockData = listOf(Integer.valueOf(R.drawable.slide1),Integer.valueOf(R.drawable.slide7),Integer.valueOf(R.drawable.slide5),Integer.valueOf(R.drawable.slide9))
        var introSlides = listOf(Integer.valueOf(R.drawable.deal_1),Integer.valueOf(R.drawable.deal_2),Integer.valueOf(R.drawable.deal_3))

    }

    override fun onCreateViewHolder(parent: ViewGroup): SliderAdapterVH {
        return SliderAdapterVH(LayoutInflater.from(parent.context).inflate(R.layout.image_slider_layout_item, null))
    }

    override fun onBindViewHolder(viewHolder: SliderAdapterVH, position: Int) {
        val view = viewHolder.itemView
        if (count == null) {
            count = 4
        }
        view.setOnClickListener { v -> v.context.startActivity(Intent(v.context, Redeem_deal::class.java)) }
        when {
            data != null -> {
                //Show true Data
                for(i in data.indices){
                    when(position){
                        i -> Glide.with(view.context).load(data[i]).into(viewHolder.imageViewBackground)
                    }
                }
            }
            count == 4 -> {
                //Show mock Data
                for(i in viewHolder.mockData.indices){
                    when (position) {
                        i -> Glide.with(view.context).load(viewHolder.mockData[i]).into(viewHolder.imageViewBackground)
                    }
                }
            }
            count == 3 -> {
                //Show Intro Slides
                for(i in viewHolder.introSlides.indices){
                    when (position) {
                        i -> Glide.with(view.context).load(viewHolder.introSlides[i]).into(viewHolder.imageViewBackground)
                    }
                }
            }
        }
    }

    override fun getCount(): Int {
        return count!!
    }

}
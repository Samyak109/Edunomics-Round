package m.rachitpahwa.deallionaries.pojos

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName


class ClaimDeal {

    @SerializedName("msg")
    @Expose
    var responseMsg: String? = null
    @SerializedName("verificationcode")
    @Expose
    var verificationcode: String? = null
    @SerializedName("dealid")
    @Expose
    var dealid: String? = null
    @SerializedName("merchantid")
    @Expose
    var merchantid: String? = null
    @SerializedName("paidprice")
    @Expose
    var paidprice: String? = null
    @SerializedName("savingamount")
    @Expose
    var savingamount: String? = null
    @SerializedName("useloyaltypoint")
    @Expose
    var useloyaltypoint: String? = null

}
package m.rachitpahwa.deallionaries.Activities

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity
import m.rachitpahwa.deallionaries.R.id
import m.rachitpahwa.deallionaries.R.layout

class Searchbar : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(layout.activity_searchbar)
        supportActionBar!!.hide()
        (findViewById<View>(id.image_close) as ImageView).setOnClickListener { this@Searchbar.startActivity(Intent(this@Searchbar, ContentMainActivity::class.java)) }
    }
}
package m.rachitpahwa.deallionaries.utils

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.SharedPreferences.Editor
import m.rachitpahwa.deallionaries.Activities.Login

class SharedPrefManager(private var _context: Context) {
    // Shared Preferences
    private var pref: SharedPreferences
    // Editor for Shared preferences
    private var editor: Editor
    // Shared pref mode
    private var PRIVATE_MODE = 0

    fun createLoginSession(token: String?) {
        // Storing login value as TRUE
        editor.putBoolean(IS_LOGIN, true)
        // Storing token in pref
        editor.putString(KEY_TOKEN, token)
        // commit changes
        editor.commit()
    }

    fun checkLogin(activity: Activity) {
        // Check login status
        if (!isLoggedIn) {
            // user is not logged in redirect him to Login Activity
            val i = Intent(_context, Login::class.java)
            // Closing all the Activities
            i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
            // Add new Flag to start new Activity
            i.flags = Intent.FLAG_ACTIVITY_NEW_TASK
            // Staring Login Activity
            _context.startActivity(i)
            activity.finish()
        }
    }

    val userDetails: String?
        get() = pref.getString(KEY_TOKEN, null)

    fun logoutUser() {
        // Clearing all data from Shared Preferences
        editor.clear()
        editor.commit()

        // After logout redirect user to Loing Activity
        /*Intent i = new Intent(_context, LoginActivity.class);
        // Closing all the Activities
        i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        // Add new Flag to start new Activity
        i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        // Staring Login Activity
        _context.startActivity(i);*/

        val i = Intent(_context, Login::class.java)
        i.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        _context.startActivity(i) // Launch the Homescreen Activity
        //_finish();

    }

    val isLoggedIn: Boolean
        get() = pref.getBoolean(IS_LOGIN, false)

    companion object {
        // Sharedpref file name
        private const val PREF_NAME = "Login"
        // All Shared Preferences Keys
        private const val IS_LOGIN = "IsLoggedIn"
        const val KEY_TOKEN = "token"
    }

    init {
        pref = _context.getSharedPreferences(PREF_NAME, PRIVATE_MODE)
        editor = pref.edit()
    }
}
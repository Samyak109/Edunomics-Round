package m.rachitpahwa.deallionaries.Model

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class Loginresponse{

    @SerializedName("msg")
    @Expose
    var message: String? = null

    @SerializedName("tokenkey")
    @Expose
    var token: String? = null

    @SerializedName("error")
    @Expose
    val isError: Boolean? = null
}
package m.rachitpahwa.deallionaries.API

import com.google.gson.annotations.SerializedName

class LandingPageResponse(@field:SerializedName("id") val id: Int,
                          @field:SerializedName("category_name") val category_name: String,
                          @field:SerializedName("banner_image") val banner_image: String,
                          @field:SerializedName("title") val title: String,
                          @field:SerializedName("description") val description: String,
                          @field:SerializedName("deal_image") val deal_image: String)
package m.rachitpahwa.deallionaries.fragments

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.GridLayoutManager
import com.xwray.groupie.GroupAdapter
import com.xwray.groupie.GroupieViewHolder
import kotlinx.android.synthetic.main.fragment_content_main.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import m.rachitpahwa.deallionaries.API.RetrofitClient
import m.rachitpahwa.deallionaries.R
import m.rachitpahwa.deallionaries.utils.SharedPrefManager
import m.rachitpahwa.deallionaries.adapter.*
import m.rachitpahwa.deallionaries.pojos.PostList

class ContentMain : Fragment() {

    private var sharedPrefManager: SharedPrefManager? = null
    private var Slider: SliderAdapterExample? = null
    private var verticalCategoriesAdapter: GroupAdapter<GroupieViewHolder>? = null
    private var verticalDealsAdapter: GroupAdapter<GroupieViewHolder>? = null
    private var list: PostList? = null

    private var job: Job = Job()
    private var uiScope = CoroutineScope(Dispatchers.Main)

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_content_main, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        sharedPrefManager = context?.let { SharedPrefManager(it) }
        //RecyclerView
        verticalCategoriesAdapter = GroupAdapter()
        verticalDealsAdapter = GroupAdapter()
        //Slider
        Slider = SliderAdapterExample(3, null)
        imageSlider.sliderAdapter = Slider
        imageSlider.scrollTimeInSec = 4
        Slider = SliderAdapterExample(4, null)
        imageSlider2.sliderAdapter = Slider
        imageSlider2.scrollTimeInSec = 4

        //Call API
        val apiService = RetrofitClient.apiService
        uiScope.launch {
            val data = apiService.getlanding()
            getdata(data)
        }
    }

    private fun getdata(data: PostList?) {
        list = data

        //Step 1: Outer RecyclerView, takes in a List of RecyclerviewHolders
        list?.categories?.forEach {
            verticalCategoriesAdapter?.add(ItemCategoriesViewHolder(it))
        }
        recyclerview_categories.layoutManager = GridLayoutManager(context, 5)
        recyclerview_categories.adapter = verticalCategoriesAdapter
        //Step 2: RecyclerViewHolder should accept the model itself as whole
        //Null or Blank Check
        if(!list?.latest.isNullOrEmpty())
            verticalDealsAdapter?.add(ItemLatestDeals(list?.latest))
        //Null or Blank Check
        if(!list?.deals.isNullOrEmpty())
            verticalDealsAdapter?.add(ItemDeals(list?.deals))
        //Null or Blank Check
        if(!list?.specialOffer.isNullOrEmpty())
            verticalDealsAdapter?.add(ItemSpecialOffers(list?.specialOffer))
        //Null or Blank Check
        if(!list?.hotels.isNullOrEmpty())
            verticalDealsAdapter?.add(ItemHotels(list?.hotels))
        //Null or Blank Check
        if(!list?.beautyandfitness.isNullOrEmpty())
            verticalDealsAdapter?.add(ItemBeautyNfit(list?.beautyandfitness))
        //Null or Blank Check
        if(!list?.electronics.isNullOrEmpty())
            verticalDealsAdapter?.add(ItemElectronics(list?.electronics))
        //Null or Blank Check
        if(!list?.activities.isNullOrEmpty())
            verticalDealsAdapter?.add(ItemActivities(list?.activities))
        //Null or Blank Check
        if(!list?.kids.isNullOrEmpty())
            verticalDealsAdapter?.add(ItemKids(list?.kids))
        //Null or Blank Check
        if(!list?.homedecoration.isNullOrEmpty())
            verticalDealsAdapter?.add(ItemHomeDecorations(list?.homedecoration))
        //Null or Blank Check
        if(!list?.retailstore.isNullOrEmpty())
            verticalDealsAdapter?.add(ItemRetailStore(list?.retailstore))
        //Null or Blank Check
        if(!list?.onlinebusiness.isNullOrEmpty())
            verticalDealsAdapter?.add(ItemOnlineBusiness(list?.onlinebusiness))
        //Null or Blank Check
        if(!list?.regularservies.isNullOrEmpty())
            verticalDealsAdapter?.add(ItemRegularServices(list?.regularservies))
        //Step 3: Mini RecyclerViewHolders each inside, will inflate their own class accordingly
        recycler1.adapter = verticalDealsAdapter
    }

}

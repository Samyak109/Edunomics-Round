package m.rachitpahwa.deallionaries.pojos

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName


class BusinessByCategory {

    @SerializedName("searchbusiness")
    @Expose
    var searchbusiness: List<Searchbusiness>? = null

}
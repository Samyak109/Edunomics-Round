package m.rachitpahwa.deallionaries.Customs

import android.app.Dialog
import android.content.Context
import android.os.Bundle
import android.view.View
import android.view.View.OnClickListener
import android.widget.Button
import m.rachitpahwa.deallionaries.R.id
import m.rachitpahwa.deallionaries.R.layout
import m.rachitpahwa.deallionaries.utils.SharedPrefManager

class CustomLogoutAlertDialog(context: Context?) : Dialog(context), OnClickListener {
    //var dialog: Dialog? = null
    var yes: Button? = null
    var no: Button? = null
    internal var sharedPrefManager: SharedPrefManager? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(layout.alert_dialog_logout)
        sharedPrefManager = SharedPrefManager(context)
        yes = findViewById<View>(id.logout_yes) as Button
        no = findViewById<View>(id.cancel) as Button
        yes?.setOnClickListener(this)
        no?.setOnClickListener(this)
    }

    override fun onClick(view: View) {
        when (view.id) {
            id.logout_yes -> sharedPrefManager?.logoutUser()
            //activity.finish();

            id.cancel -> dismiss()
            else -> {
            }
        }
        dismiss()
    }

}
package m.rachitpahwa.deallionaries.pojos

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class AppLoyaltypoints {
    @SerializedName("applevelpoints")
    @Expose
    var app: List<App>? = null

}
package m.rachitpahwa.deallionaries.fragments

import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.xwray.groupie.GroupAdapter
import com.xwray.groupie.GroupieViewHolder
import kotlinx.android.synthetic.main.fragment_favourites_deals.*
import m.rachitpahwa.deallionaries.API.RetrofitClient

import m.rachitpahwa.deallionaries.R
import m.rachitpahwa.deallionaries.utils.SharedPrefManager
import m.rachitpahwa.deallionaries.adapter.ItemMyFavourites
import m.rachitpahwa.deallionaries.pojos.MyFavourites1
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class FavouritesDeals : Fragment() {

    private var favDetails: MyFavourites1? = null
    internal var token: String? = null
    internal var sharedPrefManager: SharedPrefManager? = null

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_favourites_deals, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val adapter = GroupAdapter<GroupieViewHolder>()
        sharedPrefManager = context?.let { SharedPrefManager(it) }
        token = sharedPrefManager?.userDetails
        //Call API
        val apiService = RetrofitClient.apiService
        apiService.getmyfavourites(token)?.enqueue(object : Callback<MyFavourites1?> {
            override fun onResponse(call: Call<MyFavourites1?>?, response: Response<MyFavourites1?>) {
                if(response.isSuccessful){
                    favDetails = response.body()
                    favDetails?.getfavouritedeatil?.forEach {
                        adapter.add(ItemMyFavourites(it))
                    }
                }
            }

            override fun onFailure(call: Call<MyFavourites1?>?, t: Throwable) {
                Log.d("loop", t.message)
            }
        })
        favourites_recyclerview.adapter = adapter
    }

}

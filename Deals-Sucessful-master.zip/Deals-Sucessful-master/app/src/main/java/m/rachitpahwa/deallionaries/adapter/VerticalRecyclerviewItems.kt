package m.rachitpahwa.deallionaries.adapter

import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import com.xwray.groupie.GroupAdapter
import com.xwray.groupie.GroupieViewHolder
import com.xwray.groupie.Item
import kotlinx.android.synthetic.main.item_horizontal_recyclerviewholder.view.*
import m.rachitpahwa.deallionaries.R
import m.rachitpahwa.deallionaries.pojos.*

class ItemBanner(): Item<GroupieViewHolder>(){
    override fun getLayout(): Int {
        return R.layout.item_horizontal_recyclerviewholder
    }

    override fun bind(viewHolder: GroupieViewHolder, position: Int) {
        val view = viewHolder.itemView

        view.horizontal_title
        view.horizontal_recycler
    }
}

class ItemDeals(private val deals: List<Deal>?): Item<GroupieViewHolder>(){
    override fun getLayout(): Int {
        return R.layout.item_horizontal_recyclerviewholder
    }

    override fun bind(viewHolder: GroupieViewHolder, position: Int) {
        val view = viewHolder.itemView

        val adapter = GroupAdapter<GroupieViewHolder>()
        if (!deals?.isEmpty()!!) {
            view.horizontal_title.text = "Deals"
            deals.forEach {
                adapter.add(ItemHorizontalRecyclerViewHolder(it.id,it.title, it.dealImage, it.merchantImage, it.description))
            }
            view.horizontal_recycler.layoutManager = LinearLayoutManager(view.context, LinearLayoutManager.HORIZONTAL, false)
            view.horizontal_recycler.adapter = adapter
        }
    }
}

class ItemSpecialOffers(private val spOffer: List<SpecialOfferPojo>?): Item<GroupieViewHolder>(){
    override fun getLayout(): Int {
        return R.layout.item_horizontal_recyclerviewholder
    }

    override fun bind(viewHolder: GroupieViewHolder, position: Int) {
        val view = viewHolder.itemView


        val adapter = GroupAdapter<GroupieViewHolder>()
        if (!spOffer?.isEmpty()!!) {
            view.horizontal_title.text = "Special Offers"
            spOffer.forEach {
                adapter.add(ItemHorizontalRecyclerViewHolder(it.id, it.title, it.dealImage, it.merchantImage, it.description))
            }
            view.horizontal_recycler.layoutManager = LinearLayoutManager(view.context, LinearLayoutManager.HORIZONTAL, false)
            view.horizontal_recycler.adapter = adapter
        }
    }
}

class ItemLatestDeals(private val latest: List<Latest>?): Item<GroupieViewHolder>(){
    override fun getLayout(): Int {
        return R.layout.item_horizontal_recyclerviewholder
    }

    override fun bind(viewHolder: GroupieViewHolder, position: Int) {
        val view = viewHolder.itemView

        val adapter = GroupAdapter<GroupieViewHolder>()
        if (!latest?.isEmpty()!!) {
            view.horizontal_title.text = "Deals Of the Day"
            latest.forEach {
                adapter.add(ItemHorizontalRecyclerViewHolder(it.id, it.title, it.dealImage, it.merchantImage, it.description))
            }
            view.horizontal_recycler.layoutManager = LinearLayoutManager(view.context, LinearLayoutManager.HORIZONTAL, false)
            view.horizontal_recycler.adapter = adapter
        }
    }
}

class ItemHotels(private val hotels: List<Hotel>?): Item<GroupieViewHolder>(){
    override fun getLayout(): Int {
        return R.layout.item_horizontal_recyclerviewholder
    }

    override fun bind(viewHolder: GroupieViewHolder, position: Int) {
        val view = viewHolder.itemView

        val adapter = GroupAdapter<GroupieViewHolder>()
        if (!hotels?.isEmpty()!!) {
            view.horizontal_title.text = "Hotels"
            hotels.forEach {
                adapter.add(ItemHorizontalRecyclerViewHolder(it.id, it.title, it.dealImage, it.merchantImage, it.description))
            }
            view.horizontal_recycler.layoutManager = LinearLayoutManager(view.context, LinearLayoutManager.HORIZONTAL, false)
            view.horizontal_recycler.adapter = adapter
        }
    }
}

class ItemBeautyNfit(private val beautyNfit: List<Beautyandfitness>?): Item<GroupieViewHolder>(){
    override fun getLayout(): Int {
        return R.layout.item_horizontal_recyclerviewholder
    }

    override fun bind(viewHolder: GroupieViewHolder, position: Int) {
        val view = viewHolder.itemView

        val adapter = GroupAdapter<GroupieViewHolder>()
        if (!beautyNfit?.isEmpty()!!) {
            view.horizontal_title.text = "Beauty and Fitness"
            beautyNfit.forEach {
                adapter.add(ItemHorizontalRecyclerViewHolder(it.id, it.title, it.dealImage, it.merchantImage, it.description))
            }
            view.horizontal_recycler.layoutManager = LinearLayoutManager(view.context, LinearLayoutManager.HORIZONTAL, false)
            view.horizontal_recycler.adapter = adapter
        }
    }
}

class ItemElectronics(private val electronics: List<Electronic>?): Item<GroupieViewHolder>(){
    override fun getLayout(): Int {
        return R.layout.item_horizontal_recyclerviewholder
    }

    override fun bind(viewHolder: GroupieViewHolder, position: Int) {
        val view = viewHolder.itemView

        val adapter = GroupAdapter<GroupieViewHolder>()
        if (!electronics?.isEmpty()!!) {
            view.horizontal_title.text = "Electronics"
            electronics.forEach {
                adapter.add(ItemHorizontalRecyclerViewHolder(it.id, it.title, it.dealImage, it.merchantImage, it.description))
            }
            view.horizontal_recycler.layoutManager = LinearLayoutManager(view.context, LinearLayoutManager.HORIZONTAL, false)
            view.horizontal_recycler.adapter = adapter
        }
    }
}

class ItemActivities(private val activities: List<Activities>?): Item<GroupieViewHolder>(){
    override fun getLayout(): Int {
        return R.layout.item_horizontal_recyclerviewholder
    }

    override fun bind(viewHolder: GroupieViewHolder, position: Int) {
        val view = viewHolder.itemView

        val adapter = GroupAdapter<GroupieViewHolder>()
        if (!activities?.isEmpty()!!) {
            view.horizontal_title.text = "Activities"
            activities.forEach {
                adapter.add(ItemHorizontalRecyclerViewHolder(it.id, it.title, it.dealImage, it.merchantImage, it.description))
            }
            view.horizontal_recycler.layoutManager = LinearLayoutManager(view.context, LinearLayoutManager.HORIZONTAL, false)
            view.horizontal_recycler.adapter = adapter
        }
    }
}

class ItemKids(private val kids: List<Kid>?): Item<GroupieViewHolder>(){
    override fun getLayout(): Int {
        return R.layout.item_horizontal_recyclerviewholder
    }

    override fun bind(viewHolder: GroupieViewHolder, position: Int) {
        val view = viewHolder.itemView

        val adapter = GroupAdapter<GroupieViewHolder>()
        if (!kids?.isEmpty()!!) {
            view.horizontal_title.text = "Kids"
            kids.forEach {
                adapter.add(ItemHorizontalRecyclerViewHolder(it.id, it.title, it.dealImage, it.merchantImage, it.description))
            }
            view.horizontal_recycler.layoutManager = LinearLayoutManager(view.context, LinearLayoutManager.HORIZONTAL, false)
            view.horizontal_recycler.adapter = adapter
        }
    }
}

class ItemHomeDecorations(private val homeDecor: List<Homedecoration>?): Item<GroupieViewHolder>(){
    override fun getLayout(): Int {
        return R.layout.item_horizontal_recyclerviewholder
    }

    override fun bind(viewHolder: GroupieViewHolder, position: Int) {
        val view = viewHolder.itemView

        val adapter = GroupAdapter<GroupieViewHolder>()
        if (!homeDecor?.isEmpty()!!) {
            view.horizontal_title.text = "Home Decorations"
            homeDecor.forEach {
                adapter.add(ItemHorizontalRecyclerViewHolder(it.id, it.title, it.dealImage, it.merchantImage, it.description))
            }
            view.horizontal_recycler.layoutManager = LinearLayoutManager(view.context, LinearLayoutManager.HORIZONTAL, false)
            view.horizontal_recycler.adapter = adapter
        }
    }
}

class ItemRetailStore(private val retStore: List<Retailstore>?): Item<GroupieViewHolder>(){
    override fun getLayout(): Int {
        return R.layout.item_horizontal_recyclerviewholder
    }

    override fun bind(viewHolder: GroupieViewHolder, position: Int) {
        val view = viewHolder.itemView

        val adapter = GroupAdapter<GroupieViewHolder>()
        if (!retStore?.isEmpty()!!) {
            view.horizontal_title.text = "Retail Store"
            retStore.forEach {
                adapter.add(ItemHorizontalRecyclerViewHolder(it.id, it.title, it.dealImage, it.merchantImage, it.description))
            }
            view.horizontal_recycler.layoutManager = LinearLayoutManager(view.context, LinearLayoutManager.HORIZONTAL, false)
            view.horizontal_recycler.adapter = adapter
        }
    }
}

class ItemOnlineBusiness(private val OnlBuss: List<Onlinebussiness>?): Item<GroupieViewHolder>(){
    override fun getLayout(): Int {
        return R.layout.item_horizontal_recyclerviewholder
    }

    override fun bind(viewHolder: GroupieViewHolder, position: Int) {
        val view = viewHolder.itemView

        val adapter = GroupAdapter<GroupieViewHolder>()
        if (!OnlBuss?.isEmpty()!!) {
            view.horizontal_title.text = "Online Business"
            OnlBuss.forEach {
                adapter.add(ItemHorizontalRecyclerViewHolder(it.id, it.title, it.dealImage, it.merchantImage, it.description))
            }
            view.horizontal_recycler.layoutManager = LinearLayoutManager(view.context, LinearLayoutManager.HORIZONTAL, false)
            view.horizontal_recycler.adapter = adapter
        }
    }
}

class ItemRegularServices(private val regServices: List<Regularservices>?): Item<GroupieViewHolder>(){
    override fun getLayout(): Int {
        return R.layout.item_horizontal_recyclerviewholder
    }

    override fun bind(viewHolder: GroupieViewHolder, position: Int) {
        val view = viewHolder.itemView

        val adapter = GroupAdapter<GroupieViewHolder>()
        if (!regServices?.isEmpty()!!) {
            view.horizontal_title.text = "Regular Services"
            regServices.forEach {
                adapter.add(ItemHorizontalRecyclerViewHolder(it.id, it.title, it.dealImage, it.merchantImage, it.description))
            }
            view.horizontal_recycler.layoutManager = LinearLayoutManager(view.context, LinearLayoutManager.HORIZONTAL, false)
            view.horizontal_recycler.adapter = adapter
        }
    }
}
package m.rachitpahwa.deallionaries.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.google.android.material.tabs.TabLayout
import kotlinx.android.synthetic.main.fragment_notification.*
import m.rachitpahwa.deallionaries.R
import m.rachitpahwa.deallionaries.adapter.NotificationsAdapter

class Notification : Fragment() {
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.fragment_notification, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        tabLayout.addTab(tabLayout.newTab().setText("Admin Notifications"))
        tabLayout.addTab(tabLayout.newTab().setText("Merchant Notifications"))
        tabLayout.tabGravity = TabLayout.GRAVITY_FILL

        val adapter = NotificationsAdapter(childFragmentManager, tabLayout.tabCount)
        notifsViewPager.adapter = adapter
        tabLayout.setupWithViewPager(notifsViewPager)
        notifsViewPager.addOnPageChangeListener(TabLayout.TabLayoutOnPageChangeListener(tabLayout))

        tabLayout?.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab) {
                notifsViewPager.currentItem = tab.position
            }
            override fun onTabUnselected(tab: TabLayout.Tab) {

            }
            override fun onTabReselected(tab: TabLayout.Tab) {

            }
        })
    }
}
package m.rachitpahwa.deallionaries

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.viewpager.widget.ViewPager
import com.google.android.material.tabs.TabLayout
import com.google.gson.Gson
import m.rachitpahwa.deallionaries.API.RetrofitClient
import m.rachitpahwa.deallionaries.Activities.ContentMainActivity
import m.rachitpahwa.deallionaries.R.id
import m.rachitpahwa.deallionaries.R.layout
import m.rachitpahwa.deallionaries.utils.SharedPrefManager
import m.rachitpahwa.deallionaries.pojos.Count
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class Loyaltypoints : AppCompatActivity() {
    private var count: Count? = null
    private var imageView: ImageView? = null
    private var tabLayout: TabLayout? = null
    private var textView: TextView? = null
    private var viewPager: ViewPager? = null
    internal var token: String? = null
    internal var sharedPrefManager: SharedPrefManager? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        supportActionBar?.hide()
        setContentView(layout.activity_loyaltypoints)
        sharedPrefManager = SharedPrefManager(this@Loyaltypoints)
        token = sharedPrefManager?.userDetails
        textView = findViewById<View>(id.text_viewpoints123) as TextView
        imageView = findViewById<View>(id.back_loyal) as ImageView
        imageView?.setOnClickListener {
            this@Loyaltypoints.startActivity(Intent(this@Loyaltypoints, ContentMainActivity::class.java))
            finish()
        }
        tabLayout = findViewById<View>(id.loyalty_tablayout) as TabLayout
        viewPager = findViewById<View>(id.layout_viewpager) as ViewPager
        val viewPagerAdapter = ViewPagerAdapter(supportFragmentManager)
        viewPagerAdapter.Addfragment(Fragment_offerlevel(), "OFFER LEVEL")
        viewPagerAdapter.Addfragment(Fragment_applevel(), "APP LEVEL")
        viewPager?.adapter = viewPagerAdapter
        tabLayout?.setupWithViewPager(viewPager)
        getdata()
    }

    private fun getdata() {
        //Call API
        val apiService = RetrofitClient.apiService
        apiService.getCount(token)?.enqueue(object : Callback<Count?> {
            override fun onResponse(call: Call<Count?>?, response: Response<Count?>) {
                this@Loyaltypoints.count = response.body()
                Log.d("loop", Gson().toJson(this@Loyaltypoints.count))
                setdata()
            }
            override fun onFailure(call: Call<Count?>?, t: Throwable?) {}
        })
    }

    private fun setdata() {
        textView?.text = this.count?.count
    }
}
package m.rachitpahwa.deallionaries.adapter

import android.content.Intent
import android.widget.Toast
import com.like.LikeButton
import com.like.OnLikeListener
import m.rachitpahwa.deallionaries.Redeem_deal
import com.xwray.groupie.GroupieViewHolder
import com.xwray.groupie.Item
import kotlinx.android.synthetic.main.item_myfavourites.view.*
import m.rachitpahwa.deallionaries.Activities.BussinessDetailClass
import m.rachitpahwa.deallionaries.R
import m.rachitpahwa.deallionaries.pojos.Getfavouritedetail

class ItemMyFavourites(private val getfavouritedetail: Getfavouritedetail): Item<GroupieViewHolder>(){
    override fun getLayout(): Int {
        return R.layout.item_myfavourites
    }

    override fun bind(viewHolder: GroupieViewHolder, position: Int) {
        val view = viewHolder.itemView

        view.fav_usershop_name.text = getfavouritedetail.businessName
        view.fav_location.text = getfavouritedetail.businessDescription
        view.fav_rating.text = getfavouritedetail.rating
        view.fav_button.setOnLikeListener(object: OnLikeListener{
            override fun liked(likeButton: LikeButton?) {
                likeButton?.isLiked = true
                Toast.makeText(view.context, "Added to Favourites",Toast.LENGTH_SHORT).show()
            }

            override fun unLiked(likeButton: LikeButton?) {
                likeButton?.isLiked = false
                Toast.makeText(view.context, "Removed from Favourites",Toast.LENGTH_SHORT).show()
            }
        })
        view.setOnClickListener {
            v -> v.context.startActivity(Intent(v.context, BussinessDetailClass::class.java).putExtra("bussId", getfavouritedetail.id))
        }
    }
}
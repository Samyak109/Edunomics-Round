package m.rachitpahwa.deallionaries.pojos

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName


class PostList {

    @SerializedName("banner")
    @Expose
    var banner: List<Any>? = null
    @SerializedName("categories")
    @Expose
    var categories: List<Category>? = null
    @SerializedName("deals")
    @Expose
    var deals: List<Deal>? = null
    @SerializedName("special_offer")
    @Expose
    var specialOffer: List<SpecialOfferPojo>? = null
    @SerializedName("latest")
    @Expose
    var latest: List<Latest>? = null
    @SerializedName("hotels")
    @Expose
    var hotels: List<Hotel>? = null
    @SerializedName("beautyandfitness")
    @Expose
    var beautyandfitness: List<Beautyandfitness>? = null
    @SerializedName("electronics")
    @Expose
    var electronics: List<Electronic>? = null
    @SerializedName("activities")
    @Expose
    var activities: List<Activities>? = null
    @SerializedName("kids")
    @Expose
    var kids: List<Kid>? = null
    @SerializedName("homedecoration")
    @Expose
    var homedecoration: List<Homedecoration>? = null
    @SerializedName("retailstore")
    @Expose
    var retailstore: List<Retailstore>? = null
    @SerializedName("onlinebusiness")
    @Expose
    var onlinebusiness: List<Onlinebussiness>? = null
    @SerializedName("regularservies")
    @Expose
    var regularservies: List<Regularservices>? = null

}
package m.rachitpahwa.deallionaries

import android.annotation.SuppressLint
import android.content.Intent
import android.location.*
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.*
import android.widget.AdapterView.OnItemClickListener
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import m.rachitpahwa.deallionaries.Activities.ContentMainActivity
import m.rachitpahwa.deallionaries.R.id
import m.rachitpahwa.deallionaries.R.layout
import java.io.IOException
import java.util.*

class SelectLcation : AppCompatActivity(), LocationListener {
    private var city1: String? = null
    internal var location: Button? = null
    private var lst: ListView? = null
    private var places = arrayOf<String?>("New Delhi", "Gurgaon", "Noida", "Jaipur", "Bengaluru", "Mumbai", "Navi Mumbai", "Kolkata", "Hydrabad", "chennai")
    @SuppressLint("ResourceType")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(layout.activity_select_lcation)
        lst = findViewById<View>(id.places) as ListView
        location = findViewById<View>(id.button) as Button
        lst!!.adapter = ArrayAdapter<Any?>(this, 17367043, places)
        lst!!.onItemClickListener = OnItemClickListener { _, view, _, _ ->
            val cities = (view as TextView).text as String
            val intent = Intent(this@SelectLcation, ContentMainActivity::class.java)
            intent.putExtra("Cities", cities)
            this@SelectLcation.startActivity(intent)
        }
        (findViewById<View>(id.image_close2) as ImageView).setOnClickListener { this@SelectLcation.startActivity(Intent(this@SelectLcation, ContentMainActivity::class.java)) }
        location!!.setOnClickListener {
            val locationManager = this@SelectLcation.getSystemService("location") as LocationManager
            if (ActivityCompat.checkSelfPermission(this@SelectLcation, "android.permission.ACCESS_FINE_LOCATION") == 0 || ActivityCompat.checkSelfPermission(this@SelectLcation, "android.permission.ACCESS_COARSE_LOCATION") == 0) {
                locationManager.requestLocationUpdates("gps", 30000, 0.0f, this@SelectLcation)
                val location: Location? = locationManager.getLastKnownLocation(locationManager.getBestProvider(Criteria(), true))
                if (location == null) {
                    Toast.makeText(this@SelectLcation.applicationContext, "GPS signal not found", 0).show()
                }
                if (location != null) {
                    onLocationChanged(location)
                    val intent = Intent(this@SelectLcation, ContentMainActivity::class.java)
                    intent.putExtra("sublocality", city1)
                    this@SelectLcation.startActivity(intent)
                }
            }
        }
    }

    override fun onLocationChanged(location: Location) {
        val geocoder = Geocoder(this, Locale.getDefault())
        val latitude = location.latitude
        val longitude = location.longitude
        var stringBuilder = StringBuilder()
        stringBuilder.append("latitude--")
        stringBuilder.append(latitude)
        val str = "latitude"
        Log.e(str, stringBuilder.toString())
        try {
            stringBuilder = StringBuilder()
            stringBuilder.append("inside latitude--")
            stringBuilder.append(latitude)
            Log.e(str, stringBuilder.toString())
            val addresses: List<Address>? = geocoder.getFromLocation(latitude, longitude, 1)
            if (addresses != null && addresses.size > 0) {
                val address: String? = addresses[0].getAddressLine(0)
                Log.d("address", address)
                city1 = addresses[0].locality
                Log.d("locat", city1)
                val state: String? = addresses[0].adminArea
                Log.d("state", address)
                val country: String? = addresses[0].countryName
                val postalCode: String? = addresses[0].postalCode
                addresses[0].featureName
            }
        } catch (e: IOException) {
            e.printStackTrace()
        }
    }

    override fun onStatusChanged(provider: String, status: Int, extras: Bundle) {}
    override fun onProviderEnabled(provider: String) {}
    override fun onProviderDisabled(provider: String) {}
}
package m.rachitpahwa.deallionaries.pojos

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName


class SearchDealsList {

    @SerializedName("viewdealing")
    @Expose
    var viewdealing: List<Viewdealing>? = null

}
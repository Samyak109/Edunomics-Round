package m.rachitpahwa.deallionaries

import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import com.mukesh.OtpView
import m.rachitpahwa.deallionaries.R.id
import m.rachitpahwa.deallionaries.R.layout

class Forgotpassword2 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        supportActionBar?.hide()
        setContentView(layout.activity_forgotpassword2)
        (findViewById<View>(id.otp_view) as OtpView).setOtpCompletionListener { otp -> Log.d("onOtpCompleted=>", otp) }
    }
}
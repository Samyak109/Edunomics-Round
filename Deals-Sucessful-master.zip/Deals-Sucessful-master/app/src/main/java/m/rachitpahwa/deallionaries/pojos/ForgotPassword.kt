package m.rachitpahwa.deallionaries.pojos

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName


class ForgotPassword {

    @SerializedName("msg")
    @Expose
    var forgotResponse: String? = null
    @SerializedName("email")
    @Expose
    var email: String? = null

}
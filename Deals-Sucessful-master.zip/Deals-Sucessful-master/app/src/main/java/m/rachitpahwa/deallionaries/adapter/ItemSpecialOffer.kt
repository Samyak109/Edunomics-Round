package m.rachitpahwa.deallionaries.adapter

import android.content.Intent
import com.bumptech.glide.Glide
import com.xwray.groupie.GroupieViewHolder
import com.xwray.groupie.Item
import kotlinx.android.synthetic.main.item_deals_search.view.*
import kotlinx.android.synthetic.main.item_special_offer.view.*
import m.rachitpahwa.deallionaries.Model.SpecialOfferModel
import m.rachitpahwa.deallionaries.R
import m.rachitpahwa.deallionaries.Redeem_deal
import m.rachitpahwa.deallionaries.pojos.SpecialOfferDeals
import m.rachitpahwa.deallionaries.pojos.Specialoffer

class ItemSpecialOffer(private val specialOffersData: Specialoffer): Item<GroupieViewHolder>(){
    override fun getLayout(): Int {
        return R.layout.item_deals_search
    }

    override fun bind(viewHolder: GroupieViewHolder, position: Int) {
        val view = viewHolder.itemView

        view.deal_search_title.text = specialOffersData.title
        view.deal_search_desc.text = specialOffersData.description
        view.deal_search_normal_price.text = "valued at ${specialOffersData.regularPrice}"
        view.deal_search_offer_price.text = specialOffersData.discount.toString()
        Glide.with(view.context).load(specialOffersData.dealImage).into(view.deal_search_thumb)
        view.setOnClickListener {
            v -> v.context.startActivity(Intent(v.context, Redeem_deal::class.java).putExtra("dealid", specialOffersData.id))
        }
    }
}

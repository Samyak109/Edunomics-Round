package m.rachitpahwa.deallionaries.pojos

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class MyFavourites1 {
    @SerializedName("getfavouritedetail")
    @Expose
    var getfavouritedeatil: List<Getfavouritedetail>? = null
        private set

    fun setGetfavouritedetail(getfavouritedetail: List<Getfavouritedetail>?) {
        getfavouritedeatil = getfavouritedetail
    }
}
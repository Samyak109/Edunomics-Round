package m.rachitpahwa.deallionaries.fragments


import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.xwray.groupie.GroupAdapter
import com.xwray.groupie.GroupieViewHolder
import kotlinx.android.synthetic.main.fragment_admin_notifications.*
import m.rachitpahwa.deallionaries.API.RetrofitClient

import m.rachitpahwa.deallionaries.R
import m.rachitpahwa.deallionaries.utils.SharedPrefManager
import m.rachitpahwa.deallionaries.adapter.ItemAdminNotifications
import m.rachitpahwa.deallionaries.pojos.AdminNotifs
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class AdminNotifications : Fragment() {

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_admin_notifications, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val sharedPrefManager = context?.let { SharedPrefManager(it) }
        val token = sharedPrefManager?.userDetails
        val adapter = GroupAdapter<GroupieViewHolder>()
        var admin: AdminNotifs?
        //Call API
        val apiService = RetrofitClient.apiService
        apiService.getAdminNotifications(token)?.enqueue(object: Callback<AdminNotifs>{
            override fun onResponse(call: Call<AdminNotifs>, response: Response<AdminNotifs>) {
                if(response.isSuccessful){
                    admin = response.body()
                    admin?.notiadmin?.forEach {
                        adapter.add(ItemAdminNotifications(it))
                    }
                }
            }

            override fun onFailure(call: Call<AdminNotifs>, t: Throwable) {

            }
        })
        admin_recyclerview.adapter = adapter
    }

}

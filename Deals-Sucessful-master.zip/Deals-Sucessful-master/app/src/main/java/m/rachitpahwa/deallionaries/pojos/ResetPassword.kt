package m.rachitpahwa.deallionaries.pojos

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName


class ResetPassword {

    @SerializedName("msg")
    @Expose
    var resetResponse: String? = null
    @SerializedName("password")
    @Expose
    var password: String? = null

}
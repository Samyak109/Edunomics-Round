package m.rachitpahwa.deallionaries.adapter

import android.annotation.SuppressLint
import com.xwray.groupie.GroupieViewHolder
import com.xwray.groupie.Item
import kotlinx.android.synthetic.main.app_loltypoint_item.view.*
import m.rachitpahwa.deallionaries.R
import m.rachitpahwa.deallionaries.pojos.App

class ItemAppLoyaltyPoints(private val appPoints: App): Item<GroupieViewHolder>(){
    override fun getLayout(): Int {
        return R.layout.app_loltypoint_item
    }

    @SuppressLint("SetTextI18n")
    override fun bind(viewHolder: GroupieViewHolder, position: Int) {
        val view = viewHolder.itemView

        view.textView13.text = appPoints.firstName + appPoints.lastName
        view.textView14.text = appPoints.address
        view.textView15.text = appPoints.appLevelLoyaltyPoints
    }
}
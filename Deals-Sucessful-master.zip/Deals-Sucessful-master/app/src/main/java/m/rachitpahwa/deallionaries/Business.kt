package m.rachitpahwa.deallionaries

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity
import com.google.gson.Gson
import com.xwray.groupie.GroupAdapter
import com.xwray.groupie.GroupieViewHolder
import kotlinx.android.synthetic.main.activity_business.*
import m.rachitpahwa.deallionaries.API.RetrofitClient
import m.rachitpahwa.deallionaries.Activities.ContentMainActivity
import m.rachitpahwa.deallionaries.R.*
import m.rachitpahwa.deallionaries.utils.SharedPrefManager
import m.rachitpahwa.deallionaries.adapter.ItemBussinessCategory
import m.rachitpahwa.deallionaries.pojos.Buscategory
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class Business : AppCompatActivity() {
    private var buscategory: Buscategory? = null
    private var imageView: ImageView? = null
    internal var token: String? = null
    internal var sharedPrefManager: SharedPrefManager? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        supportActionBar?.hide()
        setContentView(layout.activity_business)
        sharedPrefManager = SharedPrefManager(this@Business)
        token = sharedPrefManager?.userDetails
        imageView = findViewById<View>(id.back_mybus) as ImageView
        imageView?.setOnClickListener {
            this@Business.startActivity(Intent(this@Business, ContentMainActivity::class.java))
            finish()
        }
        //Setup Recyclerview
        val adapter = GroupAdapter<GroupieViewHolder>()
        //Call API
        val apiService = RetrofitClient.apiService
        apiService.getbuscategory(token)?.enqueue(object : Callback<Buscategory?> {

            override fun onResponse(call: Call<Buscategory?>?, response: Response<Buscategory?>) {
                Log.e("Business", "onResponse: " + Gson().toJson(response.body()))
                if (response.isSuccessful) {

                    buscategory = response.body()
                    buscategory?.bussinesscategory?.forEach {
                        adapter.add(ItemBussinessCategory(it))
                    }
                }
            }

            override fun onFailure(call: Call<Buscategory?>?, t: Throwable) {
                Log.i("looh", t.message)
            }
        })
        business_recyclerview.adapter = adapter
    }
}
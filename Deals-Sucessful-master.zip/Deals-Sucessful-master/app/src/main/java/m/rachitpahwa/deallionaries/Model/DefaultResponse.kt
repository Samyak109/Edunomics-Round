package m.rachitpahwa.deallionaries.Model

import com.google.gson.annotations.SerializedName

class DefaultResponse(@field:SerializedName("msg") val message: String)
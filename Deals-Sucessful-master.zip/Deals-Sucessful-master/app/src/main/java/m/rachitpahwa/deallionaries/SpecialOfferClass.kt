package m.rachitpahwa.deallionaries

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import com.xwray.groupie.GroupAdapter
import com.xwray.groupie.GroupieViewHolder
import kotlinx.android.synthetic.main.fragment_special_offer.*
import m.rachitpahwa.deallionaries.API.RetrofitClient
import m.rachitpahwa.deallionaries.Activities.ContentMainActivity
import m.rachitpahwa.deallionaries.R.*
import m.rachitpahwa.deallionaries.utils.SharedPrefManager
import m.rachitpahwa.deallionaries.adapter.ItemSpecialOffer
import m.rachitpahwa.deallionaries.pojos.SpecialOfferDeals
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class SpecialOfferClass : AppCompatActivity() {
    private var specialOfferDeals: SpecialOfferDeals? = null
    private var imageView: ImageView? = null
    internal var token: String? = null
    internal var sharedPrefManager: SharedPrefManager? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        /*setContentView(layout.fragment_special_offer)*/
        window.setFlags(1024, 1024)
        sharedPrefManager = SharedPrefManager(this@SpecialOfferClass)
        token = sharedPrefManager!!.userDetails
        imageView = findViewById<View>(id.special_offer_back) as ImageView
        imageView!!.setOnClickListener {
            this@SpecialOfferClass.startActivity(Intent(this@SpecialOfferClass, ContentMainActivity::class.java))
            finish()
        }
        val adapter = GroupAdapter<GroupieViewHolder>()

        //Call API
        val apiService = RetrofitClient.apiService
        apiService.getSpecialOffers(token)?.enqueue(object: Callback<SpecialOfferDeals>{
            override fun onResponse(call: Call<SpecialOfferDeals>, response: Response<SpecialOfferDeals>) {
                if(response.isSuccessful){
                    specialOfferDeals = response.body()
                    specialOfferDeals?.specialoffers?.forEach {
                        adapter.add(ItemSpecialOffer(it))
                    }
                }
            }

            override fun onFailure(call: Call<SpecialOfferDeals>, t: Throwable) {

            }
        })
        special_offer.layoutManager = GridLayoutManager(applicationContext, 2)
        special_offer.adapter = adapter
    }
}
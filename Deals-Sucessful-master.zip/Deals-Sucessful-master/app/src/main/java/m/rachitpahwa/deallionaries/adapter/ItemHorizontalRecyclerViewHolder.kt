package m.rachitpahwa.deallionaries.adapter

import android.content.Intent
import com.bumptech.glide.Glide
import com.xwray.groupie.GroupieViewHolder
import com.xwray.groupie.Item
import kotlinx.android.synthetic.main.item_deals.view.*
import m.rachitpahwa.deallionaries.R
import m.rachitpahwa.deallionaries.Redeem_deal

class ItemHorizontalRecyclerViewHolder(private val dealId: Int?,
                                       private val head: String?,
                                       private val dealUrl: String?,
                                       private val merchUrl: String?,
                                       private val desc: String?): Item<GroupieViewHolder>(){
    override fun getLayout(): Int {
        return R.layout.item_deals
    }

    override fun bind(viewHolder: GroupieViewHolder, position: Int) {
        val view = viewHolder.itemView

        view.deal_title.text = head
        view.deal_desc.text = desc
        Glide.with(view.context).load(dealUrl).fitCenter().into(view.deal_thumb)
        Glide.with(view.context).load(merchUrl).fitCenter().into(view.deal_buss_image)
        view.setOnClickListener {
            val intent = Intent(view.context, Redeem_deal::class.java)
            intent.putExtra("dealid",dealId)
            view.context.startActivity(intent)
        }
    }
}

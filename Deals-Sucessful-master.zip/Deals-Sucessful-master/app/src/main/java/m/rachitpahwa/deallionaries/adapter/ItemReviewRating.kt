package m.rachitpahwa.deallionaries.adapter

import com.xwray.groupie.GroupieViewHolder
import com.xwray.groupie.Item
import kotlinx.android.synthetic.main.activity_bussiness_detail.*
import kotlinx.android.synthetic.main.item_reviews.view.*
import m.rachitpahwa.deallionaries.R
import m.rachitpahwa.deallionaries.pojos.Viewreviewrating
import java.text.SimpleDateFormat

class ItemReviewRating(val reviewData: Viewreviewrating): Item<GroupieViewHolder>(){
    override fun getLayout(): Int {
        return R.layout.item_reviews
    }
    override fun bind(viewHolder: GroupieViewHolder, position: Int) {
        val view = viewHolder.itemView

        val dateFormat = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX")
        val date = dateFormat.parse(reviewData.createdAt)
        val formatter = SimpleDateFormat("yyyy-MM-dd")
        val dateStr  = formatter.format(date)

        view.review_name.text = "${reviewData.firstName} ${reviewData.lastName}"
        view.review_rating.text = reviewData.rating
        view.review_created_at.text = dateStr
        view.review_text_message.text = reviewData.review
    }
}
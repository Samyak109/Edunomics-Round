package m.rachitpahwa.deallionaries.Activities

import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.util.Log
import android.util.Patterns
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.gson.Gson
import m.rachitpahwa.deallionaries.API.RetrofitClient
import m.rachitpahwa.deallionaries.Forgot_password
import m.rachitpahwa.deallionaries.Model.Loginresponse
import m.rachitpahwa.deallionaries.R.id
import m.rachitpahwa.deallionaries.R.layout
import m.rachitpahwa.deallionaries.utils.SharedPrefManager
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class Login : AppCompatActivity() {
    private var forgotpassword: TextView? = null
    private var loginBtn: Button? = null
    private var login_emailid: EditText? = null
    private var login_password: EditText? = null
    private var signupBtn: Button? = null
    private var skipnow: TextView? = null
    private lateinit var sp: SharedPreferences
    internal var sharedPrefManager: SharedPrefManager? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(layout.login)
        window.setFlags(1024, 1024)
        sharedPrefManager = SharedPrefManager(this@Login)
        login_emailid = findViewById<View>(id.login_emailid) as EditText
        login_password = findViewById<View>(id.login_password) as EditText
        loginBtn = findViewById<View>(id.loginBtn) as Button
        signupBtn = findViewById<View>(id.signupBtn) as Button
        skipnow = findViewById<View>(id.skipnow) as TextView
        forgotpassword = findViewById<View>(id.forgot_pass) as TextView
        sp = getSharedPreferences("login", 0)
        if (sp.getBoolean("logged", false)) {
            goToMainActivity()
        }
        val str = "android.permission.ACCESS_FINE_LOCATION"
        if (ContextCompat.checkSelfPermission(applicationContext, str) != 0) {
            val str2 = "android.permission.ACCESS_COARSE_LOCATION"
            if (ActivityCompat.checkSelfPermission(applicationContext, str2) != 0) {
                ActivityCompat.requestPermissions(this, arrayOf(str, str2), 101)
            }
        }
        skipnow!!.setOnClickListener {
            val intent = Intent(this@Login, ContentMainActivity::class.java)
            this@Login.startActivity(intent)
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
            finish()
        }
        forgotpassword!!.setOnClickListener { this@Login.startActivity(Intent(this@Login, Forgot_password::class.java)) }
        loginBtn!!.setOnClickListener { userlogin() }
        signupBtn!!.setOnClickListener { this@Login.startActivity(Intent(this@Login, Signup::class.java)) }
    }

    private fun goToMainActivity() {
        startActivity(Intent(this, ContentMainActivity::class.java))
    }

    private fun userlogin() {
        val lemail = login_emailid!!.text.toString()
        val lpass = login_password!!.text.toString()
        if (lemail.isEmpty()) {
            login_emailid?.error = "Please provide a valid ID"
            login_emailid?.requestFocus()
        } else if (!Patterns.EMAIL_ADDRESS.matcher(lemail).matches()) {
            login_emailid?.error = "Enter valid Email"
            login_emailid?.requestFocus()
        } else if (lpass.isEmpty()) {
            login_password?.error = "Password is required"
            login_password?.requestFocus()
        } else {
            Log.d("lol", lemail)
            //Call API
            val apiService = RetrofitClient.apiService
            apiService.login(lemail, lpass)?.enqueue(object : Callback<Loginresponse?> {
                override fun onResponse(call: Call<Loginresponse?>?, response: Response<Loginresponse?>) {
                    val loginresponse = response.body()
                    Log.d("login_response", Gson().toJson(loginresponse))
                    if (response.isSuccessful) {
                        when(loginresponse?.message){
                            "Email doesnot exist" -> {
                                Toast.makeText(applicationContext, "Oops, this Email Doesn't exist.", Toast.LENGTH_SHORT).show()
                                login_emailid?.error = "You can SignUp if your email doesn't exist."
                                login_emailid?.requestFocus()
                            }
                            "Wrong password" -> {
                                Toast.makeText(applicationContext, "Sorry, wrong password", Toast.LENGTH_SHORT).show()
                                login_password?.error = "Enter a Correct Password"
                                login_password?.requestFocus()
                            }
                            else -> {
                                Toast.makeText(applicationContext, "Login Successful", Toast.LENGTH_SHORT).show()
                                val intent = Intent(this@Login, ContentMainActivity::class.java)
                                val token = loginresponse?.token
                                sharedPrefManager?.createLoginSession(token)
                                intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK
                                this@Login.startActivity(intent)
                            }
                        }
                    } else {
                        Toast.makeText(applicationContext,"Ohh no, Something went wrong :(", Toast.LENGTH_SHORT).show()
                    }
                }

                override fun onFailure(call: Call<Loginresponse?>?, t: Throwable?) {}
            })
        }
    }
}
package m.rachitpahwa.deallionaries.pojos

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class Getreedemdetail {

    @SerializedName("redeemdealid")
    @Expose
    var redeemdealid: Int? = null
    @SerializedName("merchantid")
    @Expose
    var merchantid: Int? = null
    @SerializedName("dealid")
    @Expose
    var dealid: Int? = null
    @SerializedName("business_name")
    @Expose
    var businessName: String? = null
    @SerializedName("profile_image")
    @Expose
    var profileImage: String? = null
    @SerializedName("title")
    @Expose
    var title: String? = null
    @SerializedName("expiry_date")
    @Expose
    var expiryDate: String? = null
    @SerializedName("regular_price")
    @Expose
    var regularPrice: Int? = null
    @SerializedName("offer_price")
    @Expose
    var offerPrice: Int? = null
    @SerializedName("transaction_id")
    @Expose
    var transactionId: String? = null
    @SerializedName("sys_ref_code")
    @Expose
    var sysRefCode: String? = null
    @SerializedName("paid_price")
    @Expose
    var paidPrice: String? = null
    @SerializedName("status")
    @Expose
    var status: String? = null
    @SerializedName("offer_category_id")
    @Expose
    var offerCategoryId: Int? = null
    @SerializedName("offer_type_id")
    @Expose
    var offerTypeId: Int? = null
    @SerializedName("customer_base_offer_type_id")
    @Expose
    var customerBaseOfferTypeId: Int? = null

}
package m.rachitpahwa.deallionaries.pojos

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class MyDealsList {
    @SerializedName("message")
    @Expose
    var message: String? = null
    @SerializedName("getreedemdetail")
    @Expose
    var getreedemdetails: List<Getreedemdetail>? = null

}
package m.rachitpahwa.deallionaries.pojos

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName


class Specialoffer {

    @SerializedName("id")
    @Expose
    var id: Int? = null
    @SerializedName("title")
    @Expose
    var title: String? = null
    @SerializedName("description")
    @Expose
    var description: String? = null
    @SerializedName("regular_price")
    @Expose
    var regularPrice: Int? = null
    @SerializedName("offer_price")
    @Expose
    var offerPrice: Int? = null
    @SerializedName("discount")
    @Expose
    var discount: Int? = null
    @SerializedName("saving_amount")
    @Expose
    var savingAmount: Int? = null
    @SerializedName("deal_image")
    @Expose
    var dealImage: String? = null

}
package m.rachitpahwa.deallionaries.adapter

import android.content.Intent
import android.util.Log
import android.view.View
import android.widget.Toast
import com.afollestad.materialdialogs.LayoutMode
import com.afollestad.materialdialogs.MaterialDialog
import com.afollestad.materialdialogs.bottomsheets.BottomSheet
import com.afollestad.materialdialogs.callbacks.onDismiss
import com.afollestad.materialdialogs.customview.customView
import com.bumptech.glide.Glide
import com.xwray.groupie.GroupieViewHolder
import com.xwray.groupie.Item
import kotlinx.android.synthetic.main.item_mydeal.view.*
import kotlinx.android.synthetic.main.layout_complete_claim.*
import m.rachitpahwa.deallionaries.API.RetrofitClient
import m.rachitpahwa.deallionaries.R
import m.rachitpahwa.deallionaries.Redeem_deal
import m.rachitpahwa.deallionaries.utils.SharedPrefManager
import m.rachitpahwa.deallionaries.fragments.RedeemedDeals
import m.rachitpahwa.deallionaries.pojos.ClaimDeal
import m.rachitpahwa.deallionaries.pojos.Getreedemdetail
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class ItemMyDeals(private val getreedemdetail: Getreedemdetail): Item<GroupieViewHolder>(){
    override fun getLayout(): Int {
        return R.layout.item_mydeal
    }

    override fun bind(viewHolder: GroupieViewHolder, position: Int) {
        val view = viewHolder.itemView
        val sharedPrefManager = SharedPrefManager(view.context)
        val token = sharedPrefManager.userDetails

        Glide.with(view.context).load(getreedemdetail.profileImage).into(view.myDeal_imagView)
        view.mydeal_usershop_name.text = getreedemdetail.businessName
        view.mydeal_location.text = getreedemdetail.title
        view.mydeal__price.text = getreedemdetail.offerPrice.toString()
        view.mydeal_transaction_id.text = getreedemdetail.transactionId.toString()
        view.mydeal_expiry.text = getreedemdetail.expiryDate
        if(getreedemdetail.status == "1"){
            view.mydeal_claim.visibility = View.GONE
            view.mydeal_reference_code.setBackgroundResource(R.color.solid_blue)
            view.mydeal_reference_code.text = "Completed"
        } else {
            view.mydeal_claim.visibility = View.VISIBLE
            view.mydeal_claim.setOnClickListener {
                MaterialDialog(view.context, BottomSheet(LayoutMode.WRAP_CONTENT)).show {

                    //Initialie Custom Dialog View
                    customView(R.layout.layout_complete_claim)
                    //Set corner Radius
                    cornerRadius(16f)
                    //Show Title
                    title(text = "Complete Your Claim")
                    //Auto Dismiss set false
                    noAutoDismiss()

                    positiveButton(text = "Claim"){
                        val billAmount = claim_bill_amount.text.toString()
                        val loyaltyPoints = claim_user_loyalty.text.toString()
                        val savingsAmount = claim_savings_amount.text.toString()
                        val verificationCode = claim_verification_code.text.toString()

                        when{
                            billAmount.isEmpty() -> {
                                claim_bill_amount.error = "Bill Amount is Required"
                                claim_bill_amount.requestFocus()
                            }
                            verificationCode.isEmpty() -> {
                                claim_verification_code.error = "Verification Code is Required"
                                claim_verification_code.requestFocus()
                            }
                            else -> {
                                /**
                                 * CALL CLAIM DEAL API
                                 */
                                val redeemDealId = getreedemdetail.redeemdealid
                                var claimDeal: ClaimDeal? = ClaimDeal()
                                claimDeal?.dealid = getreedemdetail.dealid.toString()
                                Log.e("MyDeals","Deal ID is ${claimDeal?.dealid}")
                                claimDeal?.merchantid = getreedemdetail.merchantid.toString()
                                Log.e("MyDeals", "MerchantID is ${claimDeal?.merchantid}")
                                claimDeal?.paidprice = billAmount
                                claimDeal?.useloyaltypoint = loyaltyPoints
                                if(savingsAmount.isEmpty()){
                                    claimDeal?.savingamount = "0"
                                } else {
                                    claimDeal?.savingamount = savingsAmount
                                }
                                claimDeal?.verificationcode = verificationCode
                                //Call API
                                val apiService = RetrofitClient.apiService
                                apiService.claimDeal(token, redeemDealId, claimDeal!!)?.enqueue(object: Callback<ClaimDeal>{
                                    override fun onResponse(call: Call<ClaimDeal>, response: Response<ClaimDeal>) {
                                        if (response.isSuccessful) {
                                            claimDeal = response.body()
                                            Toast.makeText(view.context, "${claimDeal?.responseMsg}", Toast.LENGTH_SHORT).show()
                                            dismiss()
                                        }
                                    }
                                    override fun onFailure(call: Call<ClaimDeal>, t: Throwable) {

                                    }
                                })
                            }
                        }
                    }
                    negativeButton(text = "Cancel"){
                        dismiss()
                    }
                    onDismiss {
                        RedeemedDeals().refreshList()
                    }
                }
            }
            view.mydeal_reference_code.setBackgroundResource(R.color.solid_red)
            view.mydeal_reference_code.text = "Pending"
        }
        view.setOnClickListener {
            v -> v.context.startActivity(Intent(v.context, Redeem_deal::class.java))
        }
    }
}
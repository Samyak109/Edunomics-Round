package m.rachitpahwa.deallionaries.Model

class Innercategoriesmodel(var dealname: String, var price: String, var categorydealimage: Int, var fakeprice: String)
package m.rachitpahwa.deallionaries.API

import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.Retrofit.Builder
import retrofit2.converter.gson.GsonConverterFactory

object RetrofitClient {
    /*private const val URL = "http://34.93.168.103/"

    //Create Logger
    private val logger = HttpLoggingInterceptor().setLevel(HttpLoggingInterceptor.Level.BODY)

    //Create Okhttp Client
    private val okHttpClient = OkHttpClient.Builder().addInterceptor(logger)

    //Create Retrofit Builder
    private val builder = Builder().baseUrl(URL)
            .addConverterFactory(GsonConverterFactory.create())
            .client(okHttpClient.build())

    //Create Retrofit Instance
    private val retrofit = builder.build()

    //Retrofit Instance of the Api Interface will enable api call methods from the interface
    fun <T> buildService(serviceType: Class<T>): T {
        return retrofit.create(serviceType)
    }*/

    val apiService: Api by lazy {
        Builder()
                .baseUrl("http://34.93.168.103/")
                .addConverterFactory(GsonConverterFactory.create())
                .client(OkHttpClient.Builder().addInterceptor(
                        HttpLoggingInterceptor().setLevel(HttpLoggingInterceptor.Level.BODY)).build())
                .build().create(Api::class.java)
    }
}

package m.rachitpahwa.deallionaries.adapter

import android.content.Intent
import android.widget.Toast
import com.bumptech.glide.Glide
import com.like.LikeButton
import com.like.OnLikeListener
import com.xwray.groupie.GroupieViewHolder
import com.xwray.groupie.Item
import kotlinx.android.synthetic.main.item_bussiness.view.*
import m.rachitpahwa.deallionaries.API.RetrofitClient
import m.rachitpahwa.deallionaries.Activities.BussinessDetailClass
import m.rachitpahwa.deallionaries.R
import m.rachitpahwa.deallionaries.utils.SharedPrefManager
import m.rachitpahwa.deallionaries.pojos.PostDeleteFavs
import m.rachitpahwa.deallionaries.pojos.Searchbusiness
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class ItemCategoryDetail(private val searchBussiness: Searchbusiness): Item<GroupieViewHolder>(){

    private var sharedPrefManager: SharedPrefManager? = null
    override fun getLayout(): Int {
        return R.layout.item_bussiness
    }
    override fun bind(viewHolder: GroupieViewHolder, position: Int) {
        val view = viewHolder.itemView

        val token = sharedPrefManager?.userDetails

        view.buss_title.text = searchBussiness.businessName
        view.buss_loyalty.text = searchBussiness.slug
        if(searchBussiness.subcategoryName.isNullOrEmpty()){
            view.buss_cat.text = "N/A"
        } else {
            view.buss_cat.text = searchBussiness.subcategoryName
        }
        Glide.with(view.context).load(searchBussiness.profileImage).into(view.buss_item_img)

        view.buss_like_button.isLiked = !(searchBussiness.likeStatus == null || searchBussiness.likeStatus == false)

        view.buss_like_button.setOnLikeListener(object: OnLikeListener{
            override fun liked(likeButton: LikeButton?) {
                val favs = PostDeleteFavs()
                favs.merchantID = searchBussiness.id
                //Call API
                val apiService = RetrofitClient.apiService
                apiService.addToFavourites(token, favs)?.enqueue(object: Callback<PostDeleteFavs>{
                    override fun onResponse(call: Call<PostDeleteFavs>, response: Response<PostDeleteFavs>) {
                        if(response.isSuccessful){
                            Toast.makeText(view.context, "Added to Favourites", Toast.LENGTH_SHORT).show()
                        }
                    }
                    override fun onFailure(call: Call<PostDeleteFavs>, t: Throwable) {

                    }
                })
            }
            override fun unLiked(likeButton: LikeButton?) {
                //Call API
                val apiService = RetrofitClient.apiService
                apiService.removeFavourite(token, searchBussiness.id)?.enqueue(object: Callback<PostDeleteFavs>{
                    override fun onResponse(call: Call<PostDeleteFavs>, response: Response<PostDeleteFavs>) {
                        if(response.isSuccessful){
                            Toast.makeText(view.context, "Removed from Favourites", Toast.LENGTH_SHORT).show()
                        }
                    }

                    override fun onFailure(call: Call<PostDeleteFavs>, t: Throwable) {

                    }
                })
            }
        })
        view.setOnClickListener {
            v -> v.context.startActivity(Intent(v.context, BussinessDetailClass::class.java).putExtra("bussId", searchBussiness.id))
        }
    }
}

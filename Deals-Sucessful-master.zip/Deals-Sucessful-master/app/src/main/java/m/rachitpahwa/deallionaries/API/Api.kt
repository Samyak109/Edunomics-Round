package m.rachitpahwa.deallionaries.API

import m.rachitpahwa.deallionaries.Model.DefaultResponse
import m.rachitpahwa.deallionaries.Model.Loginresponse
import m.rachitpahwa.deallionaries.pojos.*
import retrofit2.Call
import retrofit2.http.*
import retrofit2.http.POST
import retrofit2.http.FormUrlEncoded
import retrofit2.http.GET

interface Api {
    @FormUrlEncoded
    @POST("api/user/add")
    fun adduser(@Field("address") str: String?,
                @Field("last_name") str2: String?,
                @Field("first_name") str3: String?,
                @Field("email") str4: String?,
                @Field("mobile_number") str5: String?,
                @Field("password") str6: String?,
                @Field("gender") str7: String?,
                @Field("date_of_birth") str8: String?): Call<DefaultResponse?>?

    @FormUrlEncoded
    @PUT("/api/user/edit_profile/44")
    fun edited(@Body editProfile: EditProfile?): Call<EditProfile?>?

    @POST("/api/user/forgot")
    fun sendForgotEmmail(): Call<ForgotPassword>?

    @POST("/api/user/reset/{token}")
    fun resetPassword(@Path("x-access-token") token: String?): Call<ResetPassword>?

    @GET("/api/dashboard/logocount")
    fun getCount(@Header("x-access-token") token: String?): Call<Count?>?

    @GET("/api/notifications/notiadmin")
    fun getAdminNotifications(@Header("x-access-token") token: String?): Call<AdminNotifs>?

    @GET("/api/notifications/notimerchant")
    fun getMerchantNotifications(@Header("x-access-token") token: String?): Call<MerchantNotifs>?

    @GET("/api/dashboard/applevelpoints")
    fun getapplayoutpoints(@Header("x-access-token") token: String?): Call<AppLoyaltypoints?>?

    //TODO Update the class from PostMan
    @GET("/api/dashboard/viewbusinesscategory")
    fun getbuscategory(@Header("x-access-token") token: String?): Call<Buscategory?>?

    @GET("/api/user/get")
    suspend fun getUserInfo(@Header("x-access-token") token: String?): EditProfile?

    @GET("/api/landing/landingpage")
    suspend fun getlanding(): PostList?

    @GET("/api/dashboard/viewdashboard")
    fun getmydashboard(@Header("x-access-token") token: String?): Call<Maindashboard?>?

    @GET("/api/dashboard/favourite")
    fun getmyfavourites(@Header("x-access-token") token: String?): Call<MyFavourites1?>?

    @POST("api/dashboard/favourite")
    fun addToFavourites(@Header("x-access-token") token: String?, @Body postDeleteFavs: PostDeleteFavs): Call<PostDeleteFavs>?

    @DELETE("api/dashboard/favourite/{id}")
    fun removeFavourite(@Header("x-access-token") token: String?, @Path("id") id: Int?): Call<PostDeleteFavs>?

    @FormUrlEncoded
    @POST("/api/user/login")
    fun login(@Field("email") str: String?, @Field("password") str2: String?): Call<Loginresponse?>?

    @GET("/api/deals/redeemdetail")
    fun mydeal(@Header("x-access-token") token: String?): Call<MyDealsList?>?

    @GET("api/dashboard/offervaluepoints")
    fun offervaluepoints(@Header("x-access-token") token: String?): Call<OfferValue?>?

    @GET("api/deals/dealsdetail/{id}")
    fun dealDetail(@Path("id") id: Int): Call<DealDetail>?

    @GET("api/business/searchbusiness")
    fun guestBusinessCategories(@Query("category") category: String?): Call<BusinessByCategory>?

    @POST("api/business/searchbusiness")
    fun userBusinessCategories(@Header("x-access-token") token: String?, @Query("category") category: String?): Call<BusinessByCategory>?

    @GET("api/dashboard/special_offers")
    fun getSpecialOffers(@Header("x-access-token") token: String?): Call<SpecialOfferDeals>?

    //TODO Change API address to /dashboard/searchdeals?category=slug
    @GET("api/deals/viewdeals?userlat=26.2235&userlong=50.5876")
    fun getSearchDeals(): Call<SearchDealsList>?

    @POST("api/deals/redeemdeal")
    fun redeemDeal(@Header("x-access-token") token: String?, @Body redeemDeal: RedeemDeal): Call<RedeemDeal>?

    @POST("api/deals/claimdeal/{id}")
    fun claimDeal(@Header("x-access-token") token: String?, @Path("id") id: Int?, @Body claimDeal: ClaimDeal): Call<ClaimDeal>?

    @GET("/api/business/detailbusiness/{id}")
    fun getBusinessDetail(@Path("id") id: Int?): Call<BussinessDetail>?

    @GET("api/business/loginbusdetail/{id}")
    fun getLoginBussinessData(@Header("x-access-token") token: String?, @Path("id") id: Int?): Call<LoginBusinessData>?
}
package m.rachitpahwa.deallionaries.Activities

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.MenuItem
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.core.view.GravityCompat
import androidx.drawerlayout.widget.DrawerLayout
import androidx.navigation.NavController
import androidx.navigation.Navigation
import androidx.navigation.ui.NavigationUI
import com.google.android.material.navigation.NavigationView
import kotlinx.android.synthetic.main.activity_content_main.*
import m.rachitpahwa.deallionaries.*
import m.rachitpahwa.deallionaries.Customs.CustomLogoutAlertDialog
import m.rachitpahwa.deallionaries.utils.SharedPrefManager
import android.util.Log
import kotlinx.android.synthetic.main.nav_header_main.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import m.rachitpahwa.deallionaries.API.RetrofitClient
import m.rachitpahwa.deallionaries.pojos.EditProfile


class ContentMainActivity : AppCompatActivity(), NavigationView.OnNavigationItemSelectedListener {

    private var sharedPrefManager: SharedPrefManager? = null
    private lateinit var drawerLayout: DrawerLayout
    private lateinit var toolbar: androidx.appcompat.widget.Toolbar
    private lateinit var navController: NavController
    private lateinit var navigationView: NavigationView
    private lateinit var drawerToggle: ActionBarDrawerToggle
    private var token: String? = null
    private var job: Job = Job()
    private val uiScope = CoroutineScope(Dispatchers.Main)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_content_main)
        sharedPrefManager = SharedPrefManager(this@ContentMainActivity)
        token = sharedPrefManager?.userDetails
        //SearchBar
        imageView2.setOnClickListener {
            this.startActivity(Intent(this@ContentMainActivity, Searchbar::class.java))
        }
        cities?.setOnClickListener {
            this.startActivity(Intent(this@ContentMainActivity, SelectLcation::class.java))
        }

        setupNavigation()
        validateLogin()

        bottomBar.onItemSelected = {
            when(it){
                0 -> navController.navigate(R.id.contentMain)
                1 -> navController.navigate(R.id.dashboard)
                2 -> navController.navigate(R.id.redeemedDeals)
                3 -> navController.navigate(R.id.notification)
                4 -> navController.navigate(R.id.favouriteDeals)
                5 -> {
                    val redirectIntent = Intent(applicationContext, Loyaltypoints::class.java)
                    startActivity(redirectIntent)
                }
            }
        }

        //Handle Navigation Pages
        navController.addOnDestinationChangedListener { _, destination, _ ->
            when(destination.id){
                R.id.contentMain -> bottomBar.setActiveItem(0)
                R.id.dashboard -> bottomBar.setActiveItem(1)
                R.id.redeemedDeals -> bottomBar.setActiveItem(2)
                R.id.notification -> bottomBar.setActiveItem(3)
                R.id.favouriteDeals -> bottomBar.setActiveItem(4)
                else -> bottomBar.setActiveItem(5)
            }
        }

        if(sharedPrefManager?.isLoggedIn!!){
            //Call API
            val apiService = RetrofitClient.apiService
            uiScope.launch {
                val profileData = apiService.getUserInfo(token)
                getUserInfo(profileData)
            }
        } else {
            val noData = EditProfile()
            noData.result?.get(0)?.firstName = "Username"
            noData.result?.get(0)?.email = "user.email@deallionaires.com"
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        job.cancel()
    }

    private fun validateLogin(){
        if (sharedPrefManager?.isLoggedIn ?: return) {
            //Show Normal Menu Items
            navigationView.menu?.setGroupVisible(R.id.VisitorsGroup, false)
        } else {
            // Only Show Login & Sign-Up
            navigationView.menu?.setGroupVisible(R.id.LoggedInUserGroup, false)
        }
    }

    private fun getUserInfo(data: EditProfile?){
        data?.result?.forEach {
            header_user_name?.text = it.firstName + " " + it.lastName
            Log.d("MainActivity", "Username is ${it.firstName} ${it.lastName}")
            header_user_email?.text = it.email
            Log.d("MainActivity", "Useremail is ${it.email}")
            //displayHeaderInfo(userName, userEmail)
        }
    }

    private fun setupNavigation(){
        toolbar = findViewById(R.id.toolbar4)
        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.setDisplayShowHomeEnabled(true)
        supportActionBar?.setHomeAsUpIndicator(R.drawable.ic_menu_black_24dp)
        supportActionBar?.setDisplayShowTitleEnabled(false)

        drawerLayout = findViewById(R.id.drawer_layout)
        drawerToggle = ActionBarDrawerToggle(this, drawerLayout, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close)
        drawerLayout.setDrawerListener(drawerToggle)
        navigationView = findViewById(R.id.navigationView)
        navController = Navigation.findNavController(this, R.id.nav_host_fragment)

        NavigationUI.setupActionBarWithNavController(this, navController)
        NavigationUI.setupWithNavController(navigationView, navController)
        navigationView.setNavigationItemSelectedListener(this)
    }

    override fun onPostCreate(savedInstanceState: Bundle?) {
        super.onPostCreate(savedInstanceState)
        drawerToggle.syncState()
    }

    override fun onNavigationItemSelected(p0: MenuItem): Boolean {

        p0.isChecked = true
        drawerLayout.closeDrawers()
        when(p0.itemId){
            //Navigate when Item is selected
            R.id.nav_home -> navController.navigate(R.id.contentMain)
            R.id.nav_deal -> {
                navController.navigate(R.id.redeemedDeals)
                //bottomBar.setActiveItem(1)
            }
            R.id.nav_deal_search -> {
                navController.navigate(R.id.searchDeals)
            }
            R.id.nav_offers -> {
                /*val i = Intent(baseContext, SpecialOfferClass::class.java)
                startActivity(i)*/
                navController.navigate(R.id.specialOfferDeals)
            }
            R.id.nav_business -> {
                val i = Intent(baseContext, Business::class.java)
                startActivity(i)
            }
            R.id.nav_favourites -> {
                navController.navigate(R.id.favouriteDeals)
                //bottomBar.setActiveItem(3)
            }
            R.id.nav_dashboard -> {
                navController.navigate(R.id.dashboard)
                //bottomBar.setActiveItem(0)
            }
            R.id.nav_account -> {
                val i = Intent(baseContext, ProfileActivity::class.java)
                startActivity(i)
            }
            R.id.user_logout -> {
                val customLogoutAlertDialog = CustomLogoutAlertDialog(this@ContentMainActivity)
                customLogoutAlertDialog.show()
            }
            R.id.nav_login -> applicationContext.startActivity(Intent(baseContext, Login::class.java))
        }
        return true
    }

    override fun onSupportNavigateUp(): Boolean {

        navController.popBackStack(R.id.contentMain, true)
        return NavigationUI.navigateUp(navController, drawerLayout)
    }

    override fun onBackPressed() {
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START)
        } else {
            super.onBackPressed()
        }
    }
}

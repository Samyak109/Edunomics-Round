package m.rachitpahwa.deallionaries.pojos

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class Retailstore {
    @SerializedName("id")
    @Expose
    var id: Int? = null
    @SerializedName("title")
    @Expose
    var title: String? = null
    @SerializedName("description")
    @Expose
    var description: String? = null
    @SerializedName("deal_image")
    @Expose
    var dealImage: String? = null
    @SerializedName("merchantsimage")
    @Expose
    var merchantImage: String? = null
}
package m.rachitpahwa.deallionaries.Activities

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import androidx.appcompat.app.AppCompatActivity
import m.rachitpahwa.deallionaries.R.layout
import m.rachitpahwa.deallionaries.utils.SharedPrefManager

class Splashscreen : AppCompatActivity() {
    private val SPLASH_DISPLAY_LENGTH = 1000
    internal var sharedPrefManager: SharedPrefManager? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        supportActionBar!!.hide()
        setContentView(layout.activity_splashscreen)
        Handler().postDelayed({
            sharedPrefManager = SharedPrefManager(this@Splashscreen)
            if (sharedPrefManager!!.isLoggedIn) {
                this@Splashscreen.startActivity(Intent(this@Splashscreen, ContentMainActivity::class.java))
                finish()
            } else {
                this@Splashscreen.startActivity(Intent(this@Splashscreen, Login::class.java))
                finish()
            }
        }, 1000)
    }
}
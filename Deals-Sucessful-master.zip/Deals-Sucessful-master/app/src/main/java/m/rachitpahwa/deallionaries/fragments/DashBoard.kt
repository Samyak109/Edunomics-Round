package m.rachitpahwa.deallionaries.fragments

import android.content.Intent
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.navigation.NavController
import androidx.navigation.Navigation
import androidx.navigation.fragment.NavHostFragment
import androidx.navigation.ui.NavigationUI
import com.google.gson.Gson
import kotlinx.android.synthetic.main.fragment_dash_board.*
import m.rachitpahwa.deallionaries.*
import m.rachitpahwa.deallionaries.API.RetrofitClient

import m.rachitpahwa.deallionaries.utils.SharedPrefManager
import m.rachitpahwa.deallionaries.pojos.Maindashboard
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class DashBoard : Fragment() {

    private var maindashboard: Maindashboard? = null
    private var value: String? = null
    private var token: String? = null
    private var sharedPrefManager: SharedPrefManager? = null

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_dash_board, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        sharedPrefManager = context?.let { SharedPrefManager(it) }
        token = sharedPrefManager?.userDetails
        mydeal.setOnClickListener { NavHostFragment.findNavController(this).navigate(R.id.redeemedDeals) }
        businesscategories.setOnClickListener { context?.startActivity(Intent(context, Business::class.java)) }
        dash_category_thumb.setOnClickListener { context?.startActivity(Intent(context, Business::class.java)) }
        myloyaltypoints.setOnClickListener { context?.startActivity(Intent(context, Loyaltypoints::class.java)) }
        favourites.setOnClickListener { Navigation.findNavController(view).navigate(R.id.favouriteDeals) }
        setdata()
    }

    private fun setdata() {
        //Call API
        val apiService = RetrofitClient.apiService
        apiService.getmydashboard(token)?.enqueue(object : Callback<Maindashboard?> {
            override fun onResponse(call: Call<Maindashboard?>?, response: Response<Maindashboard?>) {
                Log.i("loooc", Gson().toJson(response.body()))
                maindashboard = response.body()
                value = Gson().toJson(response.body())
                getdata()
            }

            override fun onFailure(call: Call<Maindashboard?>?, t: Throwable?) {}
        })
    }

    private fun getdata() {
        val deal = maindashboard?.dashboard
        Log.i("log", deal.toString())
        deal_not.text = "Points: ${deal?.get(0)?.get(0)?.myDeals}"
        loyalt_not.text = "Points: ${deal?.get(2)?.get(0)?.loyalty_points}"
        fav_not.text = "Points: ${deal?.get(1)?.get(0)?.favourites}"
    }

}

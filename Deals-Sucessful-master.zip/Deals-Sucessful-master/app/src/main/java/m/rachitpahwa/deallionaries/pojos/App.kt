package m.rachitpahwa.deallionaries.pojos

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class App {
    @SerializedName("address")
    @Expose
    var address: String? = null
    @SerializedName("app_level_loyalty_points")
    @Expose
    var appLevelLoyaltyPoints: String? = null
    @SerializedName("first_name")
    @Expose
    var firstName: String? = null
    @SerializedName("last_name")
    @Expose
    var lastName: String? = null

}
package m.rachitpahwa.deallionaries.pojos

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class BussinessDetail {

    @SerializedName("viewbusinessname")
    @Expose
    var viewbusinessname: List<Viewbusinessname>? = null
    @SerializedName("viewcategoryname")
    @Expose
    var viewcategoryname: List<Viewcategoryname>? = null
    @SerializedName("viewsubcategoryname")
    @Expose
    var viewsubcategoryname: List<Viewsubcategoryname>? = null
    @SerializedName("viewbusinessrating")
    @Expose
    var viewbusinessrating: List<Viewbusinessrating>? = null
    @SerializedName("viewimages")
    @Expose
    var viewimages: List<String>? = null
    @SerializedName("viewdeals")
    @Expose
    var viewdeals: List<Viewdeal>? = null
    @SerializedName("viewbranch")
    @Expose
    var viewbranch: List<Viewbranch>? = null
    @SerializedName("viewreviewrating")
    @Expose
    var viewreviewrating: List<Viewreviewrating>? = null

}
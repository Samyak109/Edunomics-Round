package m.rachitpahwa.deallionaries.pojos

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName


class RedeemDeal {

    @SerializedName("merchantid")
    @Expose
    var merchantid: String? = null
    @SerializedName("dealid")
    @Expose
    var dealid: String? = null
    @SerializedName("offer_type_id")
    @Expose
    var offerTypeId: String? = null
    @SerializedName("offer_category_id")
    @Expose
    var offerCategoryId: String? = null
    @SerializedName("loyalty_points")
    @Expose
    var loyaltyPoints: String? = null
    @SerializedName("regular_price")
    @Expose
    var regularPrice: String? = null
    @SerializedName("offer_price")
    @Expose
    var offerPrice: String? = null
    @SerializedName("discount")
    @Expose
    var discount: String? = null
    @SerializedName("customer_base_offer_type_id")
    @Expose
    var customerBaseOfferTypeId: String? = null
    @SerializedName("msg")
    @Expose
    var dealMsg: String? = null

}
package m.rachitpahwa.deallionaries.pojos

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName


class Viewbusinessname {

    @SerializedName("business_name")
    @Expose
    var businessName: String? = null
    @SerializedName("city")
    @Expose
    var city: String? = null
    @SerializedName("profile_image")
    @Expose
    var profileImage: String? = null
    @SerializedName("address")
    @Expose
    var address: String? = null
    @SerializedName("business_description")
    @Expose
    var businessDescription: String? = null

}
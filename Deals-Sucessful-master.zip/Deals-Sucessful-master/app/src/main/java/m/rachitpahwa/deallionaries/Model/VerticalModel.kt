package m.rachitpahwa.deallionaries.Model

import java.util.*

class VerticalModel(var bannerimage: Int) {
    var arrayList: ArrayList<Horizontalmodel>? = null
    var title: String? = null

}
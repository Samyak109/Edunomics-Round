package m.rachitpahwa.deallionaries

import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.NotificationCompat
import androidx.exifinterface.media.ExifInterface
import m.rachitpahwa.deallionaries.API.Api
import m.rachitpahwa.deallionaries.API.RetrofitClient
import m.rachitpahwa.deallionaries.R.id
import m.rachitpahwa.deallionaries.R.layout
import m.rachitpahwa.deallionaries.pojos.EditProfile
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class Edit_profile_up : AppCompatActivity() {
    private var address_edit: EditText? = null
    private var city1: EditText? = null
    private var country: EditText? = null
    private var dob_edit: EditText? = null
    private var email_edit: EditText? = null
    private var fname_edit: EditText? = null
    private var gender_edit: EditText? = null
    private var lname_edit: EditText? = null
    private var mobile_edit: EditText? = null
    private var state: EditText? = null
    private var update: Button? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        supportActionBar!!.hide()
        setContentView(layout.activity_edit_profile_up)
        lname_edit = findViewById<View>(id.textView36) as EditText
        fname_edit = findViewById<View>(id.textView18_up) as EditText
        email_edit = findViewById<View>(id.edit_email_up) as EditText
        mobile_edit = findViewById<View>(id.edit_mobile_up) as EditText
        address_edit = findViewById<View>(id.textView22_up) as EditText
        gender_edit = findViewById<View>(id.edit_gender_up) as EditText
        dob_edit = findViewById<View>(id.edit_dateofbirth_up) as EditText
        city1 = findViewById<View>(id.editText5) as EditText
        state = findViewById<View>(id.editText7) as EditText
        country = findViewById<View>(id.editText8) as EditText
        update = findViewById<View>(id.update_button) as Button
        val bundle: Bundle = intent.extras
        val name: String = bundle.getString("name")
        val lname: String = bundle.getString("lname")
        var email: String = bundle.getString(NotificationCompat.CATEGORY_EMAIL)
        var mobile: String = bundle.getString("mobile")
        var address: String = bundle.getString("address")
        var city: String = bundle.getString("city")
        var state1: String = bundle.getString("state")
        var Country1: String = bundle.getString("country")
        var gender: String = bundle.getString("gender")
        var dob: String = bundle.getString("DOB")
        fname_edit!!.setText(name)
        lname_edit!!.setText(lname)
        email_edit!!.setText(email)
        mobile_edit!!.setText(mobile)
        address_edit!!.setText(address)
        city1!!.setText(city)
        state!!.setText(state1)
        country!!.setText(Country1)
        gender_edit!!.setText(gender)
        var arrSplit = dob.split(ExifInterface.GPS_DIRECTION_TRUE).toTypedArray()[0]
        dob_edit!!.setText(arrSplit)
        val button = update
        arrSplit = lname
        val dob2 = dob
        dob = email
        val gender2 = gender
        gender = mobile
        val Country12 = Country1
        Country1 = address
        val state12 = state1
        state1 = city
        city = state12
        address = Country12
        mobile = dob2
        email = gender2
        val finalArrSplit = arrSplit
        val finalDob = dob
        val finalGender = gender
        val finalCountry = Country1
        val finalState = state1
        val finalCity = city
        val finalAddress = address
        val finalMobile = mobile
        val finalEmail = email
        update!!.setOnClickListener {
            //Call API
            val apiService = RetrofitClient.apiService
            apiService.edited(editProfile = null)!!.enqueue(object : Callback<EditProfile?> {
                override fun onResponse(call: Call<EditProfile?>?, response: Response<EditProfile?>) {
                    Log.d("toorest", response.body().toString())
                    if (response.body()!!.msg!!.contains("updated sucessfully")) {
                        Log.d("toorespon", response.body()!!.msg)
                        Toast.makeText(this@Edit_profile_up, response.body()!!.msg, Toast.LENGTH_LONG).show()
                    }
                }

                override fun onFailure(call: Call<EditProfile?>?, t: Throwable) {
                    Log.d("tooress", t.message)
                }
            })
        }
    }
}
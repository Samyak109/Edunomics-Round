package m.rachitpahwa.deallionaries.adapter

import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentPagerAdapter
import androidx.fragment.app.FragmentStatePagerAdapter
import androidx.viewpager.widget.PagerAdapter
import m.rachitpahwa.deallionaries.fragments.*
import android.view.ViewGroup



class BussinessPagesAdapter(fm: FragmentManager, private var totalTabs: Int): FragmentStatePagerAdapter(fm){

    override fun getItem(position: Int): Fragment {
        return when (position) {
            0 -> BusinessDeals()
            1 -> BusinessBranches()
            2 -> BusinessContact()
            else -> return BusinessReview()
        }
    }

    override fun getPageTitle(position: Int): CharSequence? {
        return when(position){
            0 -> "Deals"
            1 -> "Branches"
            2 -> "Contact"
            else -> "Reviews"
        }
    }

    override fun getCount(): Int {
        return totalTabs
    }

    override fun getItemPosition(`object`: Any): Int {
        return PagerAdapter.POSITION_NONE
    }

}
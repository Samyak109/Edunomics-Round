package m.rachitpahwa.deallionaries.pojos

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class EditProfile {
    @SerializedName("message")
    @Expose
    var msg: String? = null
    @SerializedName("profile")
    @Expose
    var result: List<Result>? = null

}
package m.rachitpahwa.deallionaries.adapter

import android.content.Intent
import com.xwray.groupie.GroupieViewHolder
import com.xwray.groupie.Item
import kotlinx.android.synthetic.main.item_deals_search.view.*
import m.rachitpahwa.deallionaries.R
import m.rachitpahwa.deallionaries.Redeem_deal
import m.rachitpahwa.deallionaries.pojos.Viewdeal

class ItemBussDealSort(val sortedData: Viewdeal): Item<GroupieViewHolder>(){
    override fun getLayout(): Int {
        return R.layout.item_deals_search
    }

    override fun bind(viewHolder: GroupieViewHolder, position: Int) {
        val view = viewHolder.itemView

        view.deal_search_title.text = sortedData.title
        view.deal_search_desc.text = sortedData.description
        view.deal_search_offer_price.text = sortedData.offerPrice.toString()
        view.deal_search_normal_price.text = "valued at $${sortedData.regularPrice}"

        view.setOnClickListener {
            //v -> v.context.startActivity(Intent(v.context, Redeem_deal::class.java).putExtra("dealid", sortedData.))
        }
    }
}
package m.rachitpahwa.deallionaries.pojos

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName


class DealDetail {

    @SerializedName("dealsdetail")
    @Expose
    var dealsdetail: List<Dealsdetail>? = null

}
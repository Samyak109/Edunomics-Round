package m.rachitpahwa.deallionaries

import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentPagerAdapter
import java.util.*

class ViewPagerAdapter(fm: FragmentManager?) : FragmentPagerAdapter(fm!!) {
    private val fragmentList: MutableList<Fragment?> = ArrayList()
    private val fragmentListTitle: MutableList<String?> = ArrayList()
    override fun getItem(position: Int): Fragment {
        return fragmentList[position] as Fragment
    }

    override fun getCount(): Int {
        return fragmentListTitle.size
    }

    override fun getPageTitle(position: Int): CharSequence? {
        return fragmentListTitle[position]
    }

    fun Addfragment(fragment: Fragment?, title: String?) {
        fragmentList.add(fragment)
        fragmentListTitle.add(title)
    }
}
package m.rachitpahwa.deallionaries.viewModels

import androidx.lifecycle.ViewModel
import m.rachitpahwa.deallionaries.pojos.Viewbranch
import m.rachitpahwa.deallionaries.pojos.Viewdeal
import m.rachitpahwa.deallionaries.pojos.Viewreviewrating


class BussinessViewModel: ViewModel() {
    // TODO: Implement the ViewModel
    private var branchData: List<Viewbranch>? = null
    private var dealsData: List<Viewdeal>? = null
    private var reviewsData: List<Viewreviewrating>? = null
    fun sendBranch(branch: List<Viewbranch>?) {
        branchData = branch
    }
    fun sendDeals(deals: List<Viewdeal>?){
        dealsData = deals
    }
    fun sendReviews(review: List<Viewreviewrating>?){
        reviewsData = review
    }
    fun getBranch(): List<Viewbranch>? {
        return branchData
    }
    fun getDeals(): List<Viewdeal>? {
        return dealsData
    }
    fun getReviews(): List<Viewreviewrating>? {
        return reviewsData
    }
}
package m.rachitpahwa.deallionaries

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import m.rachitpahwa.deallionaries.R.layout

class Shop : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        supportActionBar!!.hide()
        setContentView(layout.activity_shop)
    }
}
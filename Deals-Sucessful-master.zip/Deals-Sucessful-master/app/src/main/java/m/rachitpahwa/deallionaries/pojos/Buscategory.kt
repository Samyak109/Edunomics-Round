package m.rachitpahwa.deallionaries.pojos

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class Buscategory {
    @SerializedName("bussinesscategory")
    @Expose
    var bussinesscategory: List<Bussinesscategory>? = null

}
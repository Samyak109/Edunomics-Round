package m.rachitpahwa.deallionaries.pojos

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName


class LoginBusinessData {

    @SerializedName("loginloyaltypoints")
    @Expose
    var loginloyaltypoints: Int? = null
    @SerializedName("loginclubexpirydate")
    @Expose
    var loginclubexpirydate: String? = null
    @SerializedName("isLiked")
    @Expose
    var likeStatus: Boolean? = null

}
package m.rachitpahwa.deallionaries.pojos

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName


class Viewsubcategoryname {

    @SerializedName("subcategory_name")
    @Expose
    var subcategoryName: String? = null

}
package m.rachitpahwa.deallionaries

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import m.rachitpahwa.deallionaries.R.*
import m.rachitpahwa.deallionaries.pojos.BusinessByCategory
import com.google.gson.Gson
import m.rachitpahwa.deallionaries.API.RetrofitClient
import androidx.recyclerview.widget.GridLayoutManager
import android.util.Log
import com.xwray.groupie.GroupAdapter
import com.xwray.groupie.GroupieViewHolder
import kotlinx.android.synthetic.main.activity_categoryinnerpage.*
import m.rachitpahwa.deallionaries.utils.SharedPrefManager
import m.rachitpahwa.deallionaries.adapter.ItemCategoryDetail
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class CategoryListPage : AppCompatActivity() {
    internal var businessByCategory: BusinessByCategory? = null
    private var category: String? = null
    private var sharedPrefManager: SharedPrefManager? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(layout.activity_categoryinnerpage)
        supportActionBar!!.hide()
        sharedPrefManager = SharedPrefManager(applicationContext)
        val token = sharedPrefManager?.userDetails
        val intent = intent
        val adapter = GroupAdapter<GroupieViewHolder>()
        category = intent.getStringExtra("category")
        Log.e("Category Inner Page", "Category is $category")

        if(sharedPrefManager?.isLoggedIn!!){
            //Call Post Method
            category?.let { //Call API
                val apiService = RetrofitClient.apiService
                apiService.userBusinessCategories(token, it) }?.enqueue(object : Callback<BusinessByCategory> {
                override fun onResponse(call: Call<BusinessByCategory>, response: Response<BusinessByCategory>) {
                    Log.e("Categoryinnerpage", "onResponse: " + Gson().toJson(response.body()))
                    if(response.isSuccessful){
                        businessByCategory = response.body()
                        businessByCategory?.searchbusiness?.forEach {
                            adapter.add(ItemCategoryDetail(it))
                        }
                    }
                }

                override fun onFailure(call: Call<BusinessByCategory>, t: Throwable) {
                    Log.e("Categoryinnerpage", "onFailure: " + t.localizedMessage)
                }
            })
        } else {
            //Call Get Method
            category?.let { //Call API
                val apiService = RetrofitClient.apiService
                apiService.guestBusinessCategories(it) }?.enqueue(object : Callback<BusinessByCategory> {
                override fun onResponse(call: Call<BusinessByCategory>, response: Response<BusinessByCategory>) {
                    Log.e("Categoryinnerpage", "onResponse: " + Gson().toJson(response.body()))
                    if(response.isSuccessful){
                        businessByCategory = response.body()
                        businessByCategory?.searchbusiness?.forEach {
                            adapter.add(ItemCategoryDetail(it))
                        }
                    }
                }

                override fun onFailure(call: Call<BusinessByCategory>, t: Throwable) {
                    Log.e("Categoryinnerpage", "onFailure: " + t.localizedMessage)
                }
            })
        }
        categoryiner.layoutManager = GridLayoutManager(this@CategoryListPage, 2)
        categoryiner.adapter = adapter

    }
}

package m.rachitpahwa.deallionaries.pojos

class SingleHorizontal(var images: Int, var title: String)